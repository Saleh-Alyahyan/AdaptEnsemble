"""Table 9 + CPU results: per-sample inference time of every component (microseconds), throughput,
model memory footprint and training time.

Requires base learners saved by a previous run (trained_models/base_learners/<dataset>_<split>/).
Usage: python -m src.evaluation.compute_overhead --device cpu --batch-size 32 --seed 0
"""
import argparse, json, os, time
import numpy as np, torch
from ..common import (load_base_learners, get_base_probs, state_for, load_split, load_yaml, ORDER, ROOT, _predict)
from ..state_construction import build_state
from ..train_adaptensemble import train_ppo


def timeit(fn, reps=20):
    fn(); t = time.perf_counter()
    for _ in range(reps): fn()
    return (time.perf_counter() - t) / reps


def dir_mb(path):
    return sum(os.path.getsize(os.path.join(path, f)) for f in os.listdir(path) if f != "train_times.json") / 1e6


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="cicids2017"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", default="cpu"); ap.add_argument("--batch-size", type=int, default=1024)
    a = ap.parse_args(); split = f"stratified_seed{a.seed}"; B = a.batch_size
    get_base_probs(a.dataset, split, a.seed, a.device)                        # ensures models are trained+saved
    bundles = load_base_learners(a.dataset, split, a.device)
    for b in bundles.values():
        if b["kind"] == "torch": b["model"].to(a.device).eval()
    X = load_split(a.dataset, split)["X_test"][:B]
    comp = {n: timeit(lambda n=n: _predict(bundles[n], X, a.device)) / B * 1e6 for n in ORDER}
    probs = [_predict(bundles[n], X, a.device) for n in ORDER]
    comp["state_construction_jsd"] = timeit(lambda: build_state(probs)) / B * 1e6
    cfg = load_yaml("config/ppo_hyperparams.yaml")
    val, _, yva, _ = get_base_probs(a.dataset, split, a.seed, a.device)
    t0 = time.time(); policy, _ = train_ppo(state_for(val), val, yva, cfg, a.seed, a.device, episodes=1); ppo_ep_s = time.time() - t0
    policy.eval(); st = torch.as_tensor(state_for(probs), device=a.device)
    def fwd():
        with torch.no_grad(): policy(st)
    comp["ppo_forward"] = timeit(fwd) / B * 1e6
    total = sum(comp.values())
    mdir = os.path.join(ROOT, "trained_models", "base_learners", f"{a.dataset}_{split}")
    pol_mb = sum(p.numel() for p in policy.parameters()) * 4 / 1e6
    critic_mb = (cfg["actor_architecture"][0] * 256 + 256 * 128 + 128) * 4 / 1e6
    times = json.load(open(os.path.join(mdir, "train_times.json")))
    out = dict(device=a.device, batch_size=B, per_sample_us=comp, total_us=total, throughput_samples_per_s=1e6 / total,
               rl_overhead_pct=100 * (comp["state_construction_jsd"] + comp["ppo_forward"]) / total,
               memory_mb=dict(base_learners=dir_mb(mdir), ppo_actor=pol_mb, ppo_actor_critic_approx=pol_mb + critic_mb),
               base_learner_train_seconds=times, ppo_seconds_per_episode_measured=ppo_ep_s,
               ppo_total_seconds_estimate=ppo_ep_s * cfg["training_episodes"])
    os.makedirs(os.path.join(ROOT, "results", "raw_per_seed"), exist_ok=True)
    json.dump(out, open(os.path.join(ROOT, "results", "raw_per_seed", f"overhead_{a.device}_bs{B}.json"), "w"), indent=2)
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
