"""Table 4: replace the 1D-CNN with TabNet inside the five-learner pool, then train PPO as usual.
Requires: pip install pytorch-tabnet. Retrains the pool (no cache), so it is slow."""
import json, os, numpy as np
from ..common import (load_split, load_yaml, set_seed, state_for, ensemble, ROOT)
from ..base_learners import train_xgboost, train_random_forest, train_lightgbm, train_mlp
from ..train_adaptensemble import train_ppo, predict_weights
from ..evaluation.metrics import full_report


def run_tabnet(a):
    from pytorch_tabnet.tab_model import TabNetClassifier
    d = load_split(a.dataset, f"stratified_seed{a.seed}"); cfg = load_yaml("config/base_learner_configs.yaml")
    C = int(d["y_train"].max() + 1); set_seed(a.seed); din = d["X_train"].shape[1]
    probs_v, probs_t = [], []
    for name, mod in [("xgboost", train_xgboost), ("random_forest", train_random_forest), ("lightgbm", train_lightgbm)]:
        m = mod.build_model(cfg[name], C, a.seed); mod.train(m, d["X_train"], d["y_train"])
        probs_v.append(m.predict_proba(d["X_val"])); probs_t.append(m.predict_proba(d["X_test"]))
    m = train_mlp.build_model(cfg["mlp"], din, C, a.seed, a.device); train_mlp.train(m, d["X_train"], d["y_train"], cfg["mlp"], a.device)
    probs_v.append(train_mlp.predict_proba(m, d["X_val"], a.device)); probs_t.append(train_mlp.predict_proba(m, d["X_test"], a.device))
    tn = TabNetClassifier(seed=a.seed, verbose=0); tn.fit(d["X_train"], d["y_train"], max_epochs=50, patience=5)
    probs_v.append(tn.predict_proba(d["X_val"])); probs_t.append(tn.predict_proba(d["X_test"]))
    pc = load_yaml("config/ppo_hyperparams.yaml")
    pol, _ = train_ppo(state_for(probs_v), probs_v, d["y_val"], pc, a.seed, a.device)
    w = predict_weights(pol, state_for(probs_t), a.device)
    rep = full_report(d["y_test"], ensemble(w, probs_t).argmax(1), C); rep.update(ablation="tabnet", seed=a.seed)
    json.dump(rep, open(os.path.join(ROOT, "results", "raw_per_seed", f"ablation_{a.dataset}_tabnet_seed{a.seed}.json"), "w"), indent=1)
    print(f"[tabnet seed={a.seed}] acc={rep['accuracy']*100:.2f}")
