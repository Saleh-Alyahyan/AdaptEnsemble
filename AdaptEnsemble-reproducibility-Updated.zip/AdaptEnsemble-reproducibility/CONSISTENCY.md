# Consistency report: manuscript ↔ code

## A. Followed exactly
Table 1 PPO hyperparameters; actor 90-256-128-5 / critic 90-256-128-1; Eq. 5–19; reward with α=0.3, β=0.1;
ECE M=15 bins, bins with <5 samples excluded, mini-batch 256; rollout buffer 2048, 10 update epochs, 100 episodes;
60/20/20 stratified split; base-learner hyperparameters (Sec. III-B); no resampling, no class weights, no
`scale_pos_weight`, no threshold adjustment; seeds 0/42/123/456/789; deterministic mean action at inference (Eq. 19);
label encoder shared across splits so C = 15 and Ds = 90 hold on every split; 41 NSL-KDD features (ordinal-encoded categoricals).

## B. Manuscript is silent or ambiguous — choices made here (state them in the paper if you keep them)
1. **PPO backend.** Manuscript (Sec. IV-A) lists Stable-Baselines3 2.2. Default here is a batched PyTorch implementation of
   the same equations, because SB3 steps one instance per Python call (~56M steps for 100 episodes). `src/ppo_sb3.py` is an
   optional SB3 cross-check (untested). SB3 has one learning rate, so it uses 3e-4 for the critic instead of 1e-3.
   Either change the manuscript wording or run the SB3 backend for the reported numbers.
   NOTE: The SB3 backend computes ECE over a sliding window of 256 individual steps (per-step approximation), whereas
   the main backend computes batch-level ECE over the full 256-instance mini-batch. Results are not directly comparable.
2. **Update schedule.** Text: update after every 2048 transitions. Algorithm 1 pseudocode: one update per episode. Code follows the text.
3. **"Policy gradient variance" (Table 5)** is undefined; we log the variance of the total gradient norm across updates.
4. **Unstated settings:** batch size 512 (MLP/CNN), CNN lr 1e-3 and early-stopping patience 5, α/β grid values, LinUCB (α_UCB=0.5,
   20k-instance subsample, 0.9/0.1 arm weighting), DQN (35-action simplex discretisation, ε-greedy decay), static-ensemble
   definitions (weighted voting ∝ validation accuracy), DES-KNN (DESlib default k).
5. **Baselines** (except DES-Oracle/DES-KNN via DESlib) are simplified re-implementations; their numbers may differ from Table 10.
6. **Accuracy (Eq. 20)** as printed divides by C; code uses standard accuracy.
7. **actor_architecture / critic_architecture in ppo_hyperparams.yaml** are documentary only; PolicyNetwork and ValueNetwork
   receive state_dim and K as constructor arguments and hardcode the 256-128 backbone. The YAML fields are never read by code.
8. **DES-Oracle naming.** The implementation uses DESlib KNORA-E (k=5, competence on D_val). This is not a true test-time oracle;
   the name follows the manuscript's oracle-region DES framing. See config/baseline_configs/des_oracle.yaml for details.

## C. Manuscript numbers that a real run must confirm — I could not verify these
1. **Confidence intervals are not Clopper-Pearson.** True exact intervals: 6/7 → [42.1%, 99.6%]; 7/7 → [59.0%, 100%].
   Section IV-C quotes e.g. Heartbleed ≈ [83.6%, 99.9%]. Regenerate with `src/evaluation/metrics.py` (field `recall_ci95`).
2. **Day-wise split cannot reach 99.61%.** Mon+Tue contain only Benign, FTP-Patator, SSH-Patator, so 12 of 15 classes never appear
   in D_train (printed by `preprocess_cicids2017.py`); Wednesday (val) adds DoS/Heartbleed only; Thu–Fri test attacks (Web, Infiltration,
   Bot, PortScan, DDoS) are unseen by every learner and by the policy. Report the real number or change the split description.
3. **Record counts.** 2,830,743 → 2,827,876 (−0.10%) is inconsistent with removing ~0.3% missing/infinite rows *and* duplicates;
   the Table 3 supports sum to 543,575 = 19.2% of 2,827,876 (implies ≈2.72M records). Compare with the counts the script prints.
4. **Heartbleed support = 7.** To my knowledge the public CICIDS2017 CSVs contain 11 Heartbleed flows, i.e. ≈2 in a 20% test split.
   Check against the data; the other rare supports (SQL-injection 4, Infiltration 7) are consistent with 20% of the public counts.
5. **Table 3 values vs supports.** Per-class P/R/F1 such as 97.14% at n = 7 are only possible as means over seeds; the package writes
   per-seed integer TP/FN/FP and CIs so this can be shown explicitly.
6. **Dataset descriptions.** NSL-KDD: 148,517 is the *total* (125,973 train + 22,544 test), not "148,517 training and 22,544 test".
   UNSW-NB15: the 257,673-record official partition has 42 features after dropping id/label/attack_cat, not 49; cross_dataset_architectures.yaml
   and preprocessing are now consistent at 42.
7. **Section numbering.** Results subsections are IV-A … IV-K (overhead = IV-H, SOTA comparison = IV-I, cross-dataset = IV-J, day-wise = IV-K).

## D. Fixes applied in this release
- `config/cross_dataset_architectures.yaml`: UNSW-NB15 num_features corrected 49 → 42; mlp_architecture input dim corrected [49,...] → [42,...].
- `src/evaluation/compute_overhead.py`: critic_mb now uses actual Ds from the state tensor instead of the hardcoded YAML value (which was always 90).
- `src/baselines/run_baseline.py` (stacking_dnn): C now uses num_classes_of(d) instead of int(d["y_train"].max()+1), consistent with the rest of the codebase.
- `src/ablations/tabnet_variant.py`: C now uses num_classes_of(d) instead of int(d["y_train"].max()+1).
- `config/baseline_configs/des_oracle.yaml`: technique description clarified; explicit note that KNORA-E on D_val is not a test-time oracle.
- `config/ppo_hyperparams.yaml`: actor_architecture and critic_architecture fields marked DOCUMENTARY ONLY with explanation.
- `CITATION.cff`: year updated to 2026.
- `src/ppo_sb3.py`: added note documenting the ECE windowing difference vs the main backend.
