"""AdaptEnsemble end-to-end (Algorithm 1).

Phase 1: train the base learners on D_train (cached; see common.get_base_probs).
Phase 2: train the PPO weight-allocation agent on D_val.
Evaluation: D_test with the deterministic mean action (Eq. 19).

Examples
  python -m src.train_adaptensemble --dataset cicids2017 --seed 0                       # main result
  python -m src.train_adaptensemble --ablation no_disagree                              # Table 4
  python -m src.train_adaptensemble --epsilon 0.1 --tag eps0.1                          # Table 7
  python -m src.train_adaptensemble --k 3 --tag K3                                      # Table 8
  python -m src.train_adaptensemble --nested-split                                      # D_pol / D_sel check
  python -m src.train_adaptensemble --split chronological                               # day-wise split
"""
import argparse, json, os, time
import numpy as np, torch
from .common import (get_base_probs, state_for, ensemble, load_yaml, set_seed, select_learners, ROOT)
from .ppo_agent import (PolicyNetwork, ValueNetwork, compute_gae, ppo_clipped_loss,
                        value_loss, entropy_bonus, total_loss)
from .reward import compute_reward
from .evaluation.metrics import full_report


def predict_weights(policy, S, device="cpu", random=False, K=5):
    if random:
        return np.random.dirichlet(np.ones(K), size=len(S))
    with torch.no_grad():
        mean, _ = policy(torch.as_tensor(S, device=device))
        return torch.softmax(mean, dim=-1).cpu().numpy()          # Eq. 19 (deterministic mean action)


def train_ppo(S_val, val_probs, y_val, cfg, seed, device="cpu", episodes=None, ablation="none",
              log_path=None, sel=None):
    """PPO on D_val. `sel=(S_sel, probs_sel, y_sel)` enables early stopping on a held-out model-selection
    split (nested-split experiment); the best policy on D_sel is restored at the end.
    Logs per episode: mean reward, ensemble accuracy of the deterministic policy on the monitoring split,
    and the variance of the total gradient norm across PPO updates (our operationalisation of the
    'policy gradient variance' in Table 5; the manuscript does not define it)."""
    set_seed(seed)
    N, Ds = S_val.shape; K = len(val_probs)
    policy = PolicyNetwork(Ds, K).to(device); critic = ValueNetwork(Ds).to(device)
    opt_a = torch.optim.Adam(policy.parameters(), lr=cfg["actor_learning_rate"])
    opt_c = torch.optim.Adam(critic.parameters(), lr=cfg["critic_learning_rate"])
    beta = 0.0 if ablation == "no_calibration" else cfg["reward_calibration_weight"]
    alpha = cfg["reward_confidence_weight"]
    S = torch.as_tensor(S_val, device=device); Nb = cfg["rollout_buffer_size"]; mb = cfg["ece"]["minibatch_size"]
    mon_S, mon_p, mon_y = (S_val, val_probs, y_val) if sel is None else sel
    best_acc, best_state, log = -1.0, None, []
    for ep in range(episodes or cfg["training_episodes"]):
        order = np.random.permutation(N)                       # one episode = one pass over D_val
        ep_rewards, gnorms = [], []
        for start in range(0, N, Nb):                          # update after every N_batch=2048 transitions
            idx = order[start:start + Nb]; s = S[idx]
            with torch.no_grad():
                raw, w, old_lp = policy.sample_action(s); vals = critic(s).cpu()
            w_np = np.random.dirichlet(np.ones(K), size=len(idx)) if ablation == "random_weights" else w.cpu().numpy()
            ens = ensemble(w_np, [p[idx] for p in val_probs])
            r = np.zeros(len(idx))
            for j in range(0, len(idx), mb):                   # ECE over mini-batches of 256
                r[j:j + mb] = compute_reward(ens[j:j + mb], y_val[idx][j:j + mb], alpha, beta,
                                             cfg["ece"]["num_bins"], cfg["ece"]["min_bin_samples"])
            ep_rewards.append(r.mean())
            if ablation == "random_weights":
                continue                                       # Table 4 'Random Weights': no learning
            adv, ret = compute_gae(torch.as_tensor(r, dtype=torch.float32), vals, 0.0,
                                   cfg["discount_gamma"], cfg["gae_lambda"])
            adv = ((adv - adv.mean()) / (adv.std() + 1e-8)).to(device); ret = ret.to(device)
            for _ in range(cfg["ppo_update_epochs"]):
                cl = ppo_clipped_loss(policy.log_prob(s, raw), old_lp, adv, cfg["clipping_epsilon"])
                vl = value_loss(critic(s), ret)
                loss = total_loss(cl, vl, entropy_bonus(policy, s), cfg["value_loss_coef"], cfg["entropy_bonus_coef"])
                opt_a.zero_grad(); opt_c.zero_grad(); loss.backward()
                gnorms.append(float(torch.nn.utils.clip_grad_norm_(policy.parameters(), float("inf"))))
                opt_a.step(); opt_c.step()
        w_mon = predict_weights(policy, mon_S, device, random=(ablation == "random_weights"), K=K)
        acc = float((ensemble(w_mon, mon_p).argmax(1) == mon_y).mean())
        log.append(dict(episode=ep + 1, mean_reward=float(np.mean(ep_rewards)), monitor_accuracy=acc,
                        grad_norm_variance=float(np.var(gnorms)) if gnorms else 0.0))
        if sel is not None and acc > best_acc:
            best_acc = acc; best_state = {k: v.clone() for k, v in policy.state_dict().items()}
    if best_state is not None:
        policy.load_state_dict(best_state)
    if log_path:
        os.makedirs(os.path.dirname(log_path), exist_ok=True); json.dump(log, open(log_path, "w"), indent=1)
    return policy, log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="cicids2017")
    ap.add_argument("--split", default=None, help="default: stratified_seed<seed>; or 'chronological'")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--ablation", default="none",
                    choices=["none", "no_disagree", "no_entropy", "no_calibration", "random_weights"])
    ap.add_argument("--k", type=int, default=None, help="use the first k learners of Table 8's order")
    ap.add_argument("--epsilon", type=float, default=None); ap.add_argument("--alpha", type=float, default=None)
    ap.add_argument("--beta", type=float, default=None); ap.add_argument("--episodes", type=int, default=None)
    ap.add_argument("--nested-split", action="store_true",
                    help="split D_val 50/50 into D_pol (policy training) and D_sel (early stopping)")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--tag", default="main")
    a = ap.parse_args()
    split = a.split or f"stratified_seed{a.seed}"
    cfg = load_yaml("config/ppo_hyperparams.yaml")
    if a.epsilon is not None: cfg["clipping_epsilon"] = a.epsilon
    if a.alpha is not None: cfg["reward_confidence_weight"] = a.alpha
    if a.beta is not None: cfg["reward_calibration_weight"] = a.beta

    val, test, yva, yte = get_base_probs(a.dataset, split, a.seed, a.device)
    val, test = select_learners(val, a.k), select_learners(test, a.k)
    K, C = len(val), val[0].shape[1]
    S_val, S_test = state_for(val, a.ablation), state_for(test, a.ablation)

    sel = None
    if a.nested_split:                                         # 10% D_pol / 10% D_sel (of the 20% D_val)
        rng = np.random.default_rng(a.seed); perm = rng.permutation(len(yva)); h = len(perm) // 2
        pol_i, sel_i = perm[:h], perm[h:]
        sel = (S_val[sel_i], [p[sel_i] for p in val], yva[sel_i])
        S_val, val, yva = S_val[pol_i], [p[pol_i] for p in val], yva[pol_i]

    name = f"{a.tag}_{a.dataset}_{a.ablation}" + (f"_K{a.k}" if a.k else "")
    t0 = time.time()
    policy, _ = train_ppo(S_val, val, yva, cfg, a.seed, a.device, a.episodes, a.ablation,
                          os.path.join(ROOT, "results", "logs", f"{name}_seed{a.seed}.json"), sel)
    train_s = time.time() - t0
    w = predict_weights(policy, S_test, a.device, random=(a.ablation == "random_weights"), K=K)
    rep = full_report(yte, ensemble(w, test).argmax(1), C)
    rep["mean_weight_per_class"] = {int(c): w[yte == c].mean(0).tolist() for c in np.unique(yte)}   # Table 6 / Fig. 7
    rep["mean_weight_global"] = w.mean(0).tolist()
    rep.update(dataset=a.dataset, split=split, seed=a.seed, ablation=a.ablation, k=K, nested_split=a.nested_split,
               epsilon=cfg["clipping_epsilon"], alpha=cfg["reward_confidence_weight"],
               beta=cfg["reward_calibration_weight"], ppo_train_seconds=train_s)
    out = os.path.join(ROOT, "results", "raw_per_seed", f"{name}{'_nested' if a.nested_split else ''}_seed{a.seed}.json")
    os.makedirs(os.path.dirname(out), exist_ok=True); json.dump(rep, open(out, "w"), indent=1)
    print(f"[{name} seed={a.seed}] acc={rep['accuracy']*100:.2f} macroF1={rep['macro_f1']*100:.2f}")


if __name__ == "__main__":
    main()
