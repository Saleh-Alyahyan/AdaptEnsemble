"""Shared helpers: data loading, base-learner training/caching/saving, ensembling.
torch is imported lazily so the tree-model / numpy paths work without it."""
import os, yaml
import numpy as np

# Pool order used everywhere (state vector layout, weight columns).
ORDER = ["xgboost", "random_forest", "lightgbm", "mlp", "1dcnn"]
# Table 8 (sensitivity to K) adds learners in this order: XGB, LGBM, RF, MLP, 1D-CNN.
SWEEP_ORDER = ["xgboost", "lightgbm", "random_forest", "mlp", "1dcnn"]
TREE_MODELS = ("xgboost", "random_forest", "lightgbm")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_yaml(rel):
    with open(os.path.join(ROOT, rel)) as f:
        return yaml.safe_load(f)


def load_split(dataset, split_name):
    d = np.load(os.path.join(ROOT, "data", "processed", dataset, f"{split_name}.npz"))
    return {k: d[k] for k in d.files}


def set_seed(seed):
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def num_classes_of(data):
    """C comes from the global label encoder (stored in the split), not from y_train, so that
    classes absent from D_train (e.g. day-wise split) still get a column."""
    if "num_classes" in data:
        return int(data["num_classes"])
    return int(max(data["y_train"].max(), data["y_val"].max(), data["y_test"].max()) + 1)


def _fit_tree(name, cfg, Xtr, ytr, C, seed):
    """Tree models need contiguous labels 0..n-1: remap seen classes, then scatter probabilities
    back into the full C-column layout (unseen classes get probability 0)."""
    from .base_learners import train_xgboost, train_random_forest, train_lightgbm
    mod = {"xgboost": train_xgboost, "random_forest": train_random_forest, "lightgbm": train_lightgbm}[name]
    seen = np.unique(ytr)
    y_m = np.searchsorted(seen, ytr)
    m = mod.build_model(cfg[name], len(seen), seed)
    mod.train(m, Xtr, y_m)
    return dict(kind="tree", mod=mod, model=m, seen=seen, C=C)


def _predict(bundle, X, device="cpu"):
    if bundle["kind"] == "tree":
        p = bundle["mod"].predict_proba(bundle["model"], X)
        full = np.zeros((p.shape[0], bundle["C"]), dtype=np.float64)
        full[:, bundle["seen"]] = p
        return full
    return bundle["mod"].predict_proba(bundle["model"], X, device)


def train_base_learners(dataset, split_name, seed, device="cpu"):
    """Phase 1: train the five base learners on D_train only. Returns dict name -> bundle."""
    from .base_learners import train_mlp, train_1dcnn
    data = load_split(dataset, split_name)
    cfg = load_yaml("config/base_learner_configs.yaml")
    C = num_classes_of(data); d_in = data["X_train"].shape[1]
    set_seed(seed)
    import time
    bundles = {}
    for n in TREE_MODELS:
        t = time.time(); bundles[n] = _fit_tree(n, cfg, data["X_train"], data["y_train"], C, seed)
        bundles[n]["train_seconds"] = time.time() - t
    t = time.time()
    m = train_mlp.build_model(cfg["mlp"], d_in, C, seed, device)
    train_mlp.train(m, data["X_train"], data["y_train"], cfg["mlp"], device)
    bundles["mlp"] = dict(kind="torch", mod=train_mlp, model=m, train_seconds=time.time() - t)
    t = time.time()
    m = train_1dcnn.build_model(cfg["cnn_1d"], d_in, C, seed, device)
    train_1dcnn.train(m, data["X_train"], data["y_train"], data["X_val"], data["y_val"], cfg["cnn_1d"], device)
    bundles["1dcnn"] = dict(kind="torch", mod=train_1dcnn, model=m, train_seconds=time.time() - t)
    return bundles


def save_base_learners(bundles, dataset, split_name, seed):
    import joblib
    out = os.path.join(ROOT, "trained_models", "base_learners", f"{dataset}_{split_name}")
    os.makedirs(out, exist_ok=True)
    for n, b in bundles.items():
        if b["kind"] == "tree":
            joblib.dump(dict(model=b["model"], seen=b["seen"], C=b["C"]), os.path.join(out, f"{n}.joblib"))
        else:
            import torch
            torch.save(b["model"].state_dict(), os.path.join(out, f"{n}.pt"))
    import json
    json.dump({n: b.get("train_seconds") for n, b in bundles.items()}, open(os.path.join(out, "train_times.json"), "w"), indent=1)
    return out


def load_base_learners(dataset, split_name, device="cpu"):
    """Reload models saved by save_base_learners (used by the overhead measurement)."""
    import joblib, torch
    from .base_learners import train_mlp, train_1dcnn
    data = load_split(dataset, split_name); C = num_classes_of(data); d_in = data["X_train"].shape[1]
    cfg = load_yaml("config/base_learner_configs.yaml")
    d = os.path.join(ROOT, "trained_models", "base_learners", f"{dataset}_{split_name}")
    from .base_learners import train_xgboost, train_random_forest, train_lightgbm
    mods = {"xgboost": train_xgboost, "random_forest": train_random_forest, "lightgbm": train_lightgbm}
    out = {}
    for n in TREE_MODELS:
        z = joblib.load(os.path.join(d, f"{n}.joblib")); out[n] = dict(kind="tree", mod=mods[n], model=z["model"], seen=z["seen"], C=z["C"])
    m = train_mlp.build_model(cfg["mlp"], d_in, C, 0, device); m.load_state_dict(torch.load(os.path.join(d, "mlp.pt"), map_location=device))
    out["mlp"] = dict(kind="torch", mod=train_mlp, model=m)
    m = train_1dcnn.build_model(cfg["cnn_1d"], d_in, C, 0, device); m.load_state_dict(torch.load(os.path.join(d, "1dcnn.pt"), map_location=device))
    out["1dcnn"] = dict(kind="torch", mod=train_1dcnn, model=m)
    return out


def get_base_probs(dataset, split_name, seed, device="cpu", use_cache=True, save_models=True):
    """Returns (val_probs[K], test_probs[K], y_val, y_test), cached on disk per (dataset, split, seed)."""
    cache = os.path.join(ROOT, "data", "cache", dataset); os.makedirs(cache, exist_ok=True)
    cpath = os.path.join(cache, f"{split_name}_seed{seed}_probs.npz")
    K = len(ORDER)
    if use_cache and os.path.exists(cpath):
        d = np.load(cpath)
        return [d[f"val_{i}"] for i in range(K)], [d[f"test_{i}"] for i in range(K)], d["y_val"], d["y_test"]
    data = load_split(dataset, split_name)
    bundles = train_base_learners(dataset, split_name, seed, device)
    if save_models:
        save_base_learners(bundles, dataset, split_name, seed)
    val = [_predict(bundles[n], data["X_val"], device) for n in ORDER]
    test = [_predict(bundles[n], data["X_test"], device) for n in ORDER]
    np.savez_compressed(cpath, y_val=data["y_val"], y_test=data["y_test"],
                        **{f"val_{i}": v for i, v in enumerate(val)}, **{f"test_{i}": t for i, t in enumerate(test)})
    return val, test, data["y_val"], data["y_test"]


def select_learners(probs_list, k=None):
    """Table 8: use the first k learners in SWEEP_ORDER (k=5 -> all five, pool order unchanged)."""
    if k is None or k >= len(ORDER):
        return probs_list
    idx = [ORDER.index(n) for n in SWEEP_ORDER[:k]]
    return [probs_list[i] for i in idx]


def ensemble(weights, probs_list):
    """Eq. 2: p(x) = sum_k w_k(x) p_k(x). weights: (N,K); probs_list: K x (N,C)."""
    P = np.stack(probs_list, axis=1)
    return np.einsum("nk,nkc->nc", weights, P)


def state_for(probs_list, ablation="none"):
    """Eq. 5-11 state; ablations drop the disagreement block or the entropy block."""
    from math import comb
    from .state_construction import build_state
    s = build_state(probs_list)
    K = len(probs_list); C = probs_list[0].shape[1]
    n_conf, n_dis = K * C, comb(K, 2)
    if ablation == "no_disagree":
        s = np.delete(s, np.s_[n_conf:n_conf + n_dis], axis=1)
    elif ablation == "no_entropy":
        s = s[:, :n_conf + n_dis]
    return s.astype(np.float32)
