"""Grid search on the validation set only (never touches D_test), as described in Section IV-A.
One-factor-at-a-time around the Table 1 defaults. Selection metric: ensemble accuracy on D_val.
Usage: python -m src.hparam_search --seeds 0 42 123 456 789"""
import argparse, json, os
import numpy as np, torch
from .common import get_base_probs, state_for, ensemble, load_yaml, ROOT
from .train_adaptensemble import train_ppo, predict_weights


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--dataset", default="cicids2017")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 42, 123, 456, 789])
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu"); a = ap.parse_args()
    base = load_yaml("config/ppo_hyperparams.yaml"); grid = load_yaml("config/hparam_grid.yaml"); res = {}
    for key, values in grid.items():
        for v in values:
            accs = []
            for s in a.seeds:
                val, _, yva, _ = get_base_probs(a.dataset, f"stratified_seed{s}", s, a.device)
                cfg = dict(base); cfg[key] = v; S = state_for(val)
                pol, _ = train_ppo(S, val, yva, cfg, s, a.device)
                accs.append(float((ensemble(predict_weights(pol, S, a.device), val).argmax(1) == yva).mean()))
            res[f"{key}={v}"] = dict(mean_val_acc=float(np.mean(accs)), std=float(np.std(accs, ddof=1)))
            print(key, v, res[f"{key}={v}"])
    out = os.path.join(ROOT, "results", "aggregated", "hparam_search_val.json")
    os.makedirs(os.path.dirname(out), exist_ok=True); json.dump(res, open(out, "w"), indent=1)


if __name__ == "__main__":
    main()
