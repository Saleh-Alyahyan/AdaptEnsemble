"""LightGBM base learner — Section III-B, component (3).

Same scale_pos_weight caveat as XGBoost: not applicable in the multiclass
setting (see response to Reviewer 1 Minor Comment 4 / Reviewer 2 Comment 4).
"""
import lightgbm as lgb


def build_model(config: dict, num_classes: int, seed: int):
    return lgb.LGBMClassifier(
        n_estimators=config["n_estimators"],
        boosting_type=config["boosting_type"],
        num_leaves=config["num_leaves"],
        learning_rate=config["learning_rate"],
        feature_fraction=config["feature_fraction"],
        objective="multiclass",
        num_class=num_classes,
        random_state=seed,
        n_jobs=-1,
        # scale_pos_weight deliberately omitted — not applicable; see docstring.
    )


def train(model, X_train, y_train):
    model.fit(X_train, y_train)
    return model


def predict_proba(model, X):
    return model.predict_proba(X)
