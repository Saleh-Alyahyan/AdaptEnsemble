"""1D-CNN base learner — Section III-B, component (5).

Two conv layers (64, 128 filters, kernel size 3) + global average pooling
+ FC classification head. Trained with unweighted cross-entropy loss, Adam,
50 epochs, early stopping.

Feature-grouping justification (response to Reviewer 2 Comment 5): CICFlowMeter's
78 features are organized into semantically contiguous blocks (forward packet
stats, backward packet stats, flow-timing stats, protocol flags/counts), which
provides locally coherent structure suitable for small-kernel convolution. For
NSL-KDD/UNSW-NB15, the raw (un-grouped) feature order is used as-is per
config/cross_dataset_architectures.yaml.
"""
import torch
import torch.nn as nn


class CNN1DBaseLearner(nn.Module):
    def __init__(self, input_dim: int, num_classes: int):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 64, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(64, 128, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.pool = nn.AdaptiveAvgPool1d(1)  # global average pooling
        self.fc = nn.Linear(128, num_classes)

    def forward(self, x):
        # x: (batch, input_dim) -> (batch, 1, input_dim)
        x = x.unsqueeze(1)
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.pool(x).squeeze(-1)  # (batch, 128)
        return self.fc(x)  # raw logits


def build_model(config: dict, input_dim: int, num_classes: int, seed: int, device="cpu"):
    torch.manual_seed(seed)
    return CNN1DBaseLearner(input_dim, num_classes).to(device)


def train(model, X_train, y_train, X_val, y_val, config: dict, device="cpu",
          patience: int = 5):
    X = torch.as_tensor(X_train, dtype=torch.float32, device=device)
    y = torch.as_tensor(y_train, dtype=torch.long, device=device)
    Xv = torch.as_tensor(X_val, dtype=torch.float32, device=device)
    yv = torch.as_tensor(y_val, dtype=torch.long, device=device)

    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = nn.CrossEntropyLoss()  # unweighted — see module docstring

    best_val_loss = float("inf")
    epochs_no_improve = 0
    batch_size = 512

    for epoch in range(config["epochs"]):
        model.train()
        perm = torch.randperm(X.size(0))
        for i in range(0, X.size(0), batch_size):
            idx = perm[i:i + batch_size]
            optimizer.zero_grad()
            loss = criterion(model(X[idx]), y[idx])
            loss.backward()
            optimizer.step()

        model.eval()
        with torch.no_grad():
            val_loss = criterion(model(Xv), yv).item()
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= patience:
                break  # early stopping
    return model


def predict_proba(model, X, device="cpu"):
    model.eval()
    with torch.no_grad():
        X_t = torch.as_tensor(X, dtype=torch.float32, device=device)
        probs = torch.softmax(model(X_t), dim=1)
    return probs.cpu().numpy()
