"""Random Forest base learner — Section III-B, component (2).

class_weight=None (default uniform weighting), no bootstrap-based
oversampling of minority classes — see response to Reviewer 1 Major
Concern 4 / Minor Comment 10.
"""
from sklearn.ensemble import RandomForestClassifier


def build_model(config: dict, num_classes: int, seed: int):
    return RandomForestClassifier(
        n_estimators=config["n_estimators"],
        criterion=config["criterion"],
        bootstrap=config["bootstrap"],
        max_features=config["max_features"],
        class_weight=None,  # explicit, per disclosure requested by reviewers
        random_state=seed,
        n_jobs=-1,
    )


def train(model, X_train, y_train):
    model.fit(X_train, y_train)
    return model


def predict_proba(model, X):
    return model.predict_proba(X)
