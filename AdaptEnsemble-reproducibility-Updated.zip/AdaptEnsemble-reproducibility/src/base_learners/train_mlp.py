"""MLP base learner — Section III-B, component (4).

Architecture: d-256-128-64-C, ReLU, batch norm, dropout 0.3, Adam, 50 epochs.
Trained with standard (unweighted) cross-entropy loss — no class-frequency
based loss weighting (see response to Reviewer 1 Major Concern 4).
"""
import torch
import torch.nn as nn


class MLPBaseLearner(nn.Module):
    def __init__(self, input_dim: int, num_classes: int, dropout: float = 0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 256), nn.BatchNorm1d(256), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(256, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(128, 64), nn.BatchNorm1d(64), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(64, num_classes),
        )

    def forward(self, x):
        return self.net(x)  # raw logits; softmax applied downstream


def build_model(config: dict, input_dim: int, num_classes: int, seed: int, device="cpu"):
    torch.manual_seed(seed)
    model = MLPBaseLearner(input_dim, num_classes, dropout=config["dropout"]).to(device)
    return model


def train(model, X_train, y_train, config: dict, device="cpu"):
    X = torch.as_tensor(X_train, dtype=torch.float32, device=device)
    y = torch.as_tensor(y_train, dtype=torch.long, device=device)
    optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"])
    criterion = nn.CrossEntropyLoss()  # unweighted — see module docstring

    model.train()
    batch_size = 512
    for epoch in range(config["epochs"]):
        perm = torch.randperm(X.size(0))
        for i in range(0, X.size(0), batch_size):
            idx = perm[i:i + batch_size]
            optimizer.zero_grad()
            logits = model(X[idx])
            loss = criterion(logits, y[idx])
            loss.backward()
            optimizer.step()
    return model


def predict_proba(model, X, device="cpu"):
    model.eval()
    with torch.no_grad():
        X_t = torch.as_tensor(X, dtype=torch.float32, device=device)
        logits = model(X_t)
        probs = torch.softmax(logits, dim=1)
    return probs.cpu().numpy()
