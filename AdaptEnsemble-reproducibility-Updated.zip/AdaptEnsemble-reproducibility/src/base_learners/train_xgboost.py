"""XGBoost base learner — Section III-B, component (1).

scale_pos_weight is intentionally NOT set: it is a binary-classification
parameter with no single-scalar equivalent under the multiclass softmax
objective used here (see response to Reviewer 1 Minor Comment 4 /
Reviewer 2 Comment 4).
"""
import xgboost as xgb


def build_model(config: dict, num_classes: int, seed: int):
    return xgb.XGBClassifier(
        n_estimators=config["n_estimators"],
        max_depth=config["max_depth"],
        learning_rate=config["learning_rate"],
        colsample_bytree=config["colsample_bytree"],
        objective="multi:softprob",
        num_class=num_classes,
        random_state=seed,
        n_jobs=-1,
        # scale_pos_weight deliberately omitted — not applicable; see docstring.
    )


def train(model, X_train, y_train):
    model.fit(X_train, y_train)
    return model


def predict_proba(model, X):
    return model.predict_proba(X)
