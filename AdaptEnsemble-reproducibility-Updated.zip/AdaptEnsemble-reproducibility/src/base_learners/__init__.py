"""Base learner pool (XGBoost, Random Forest, LightGBM, MLP, 1D-CNN). Modules are imported lazily by src/common.py."""
