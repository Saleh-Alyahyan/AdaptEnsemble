"""Table 4 non-PPO ablation variants, all operating on the same frozen base-learner
outputs and the same 90-dim state as AdaptEnsemble.

  lr_meta       Logistic regression meta-learner (CE loss)
  mlp_gating    Nonlinear MLP gating network (CE through the weighted ensemble)
  moe_gate_ce   MoE gate trained with cross-entropy (softmax gate over experts)
  linucb        Contextual bandit (LinUCB) with the identical reward
  dqn           DQN agent over a discretised weight simplex
  tabnet        Replace 1D-CNN with TabNet (needs pytorch-tabnet; retrains the pool)
(w/o disagreement / entropy / calibration and random weights: use
 `python -m src.train_adaptensemble --ablation ...`.)

Usage: python -m src.ablations.run_ablation --name mlp_gating --dataset cicids2017 --seed 0
"""
import argparse, itertools, json, os
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from ..common import get_base_probs, state_for, ensemble, load_yaml, set_seed, ROOT, ORDER
from ..reward import compute_reward
from ..evaluation.metrics import full_report


def train_gate(S, probs, y, K, hidden, epochs=30, lr=1e-3, device="cpu", topk=None):
    """Supervised gate: weights = softmax(g(s)); loss = NLL of the weighted ensemble."""
    d = S.shape[1]
    net = nn.Sequential(nn.Linear(d, hidden), nn.ReLU(), nn.Linear(hidden, hidden // 2), nn.ReLU(),
                        nn.Linear(hidden // 2, K)).to(device) if hidden else nn.Linear(d, K).to(device)
    opt = torch.optim.Adam(net.parameters(), lr=lr)
    St = torch.as_tensor(S, device=device); P = torch.as_tensor(np.stack(probs, 1), device=device, dtype=torch.float32)
    yt = torch.as_tensor(y, device=device, dtype=torch.long)
    best, bad = 1e9, 0
    for ep in range(epochs):
        perm = torch.randperm(len(St))
        for i in range(0, len(St), 512):
            b = perm[i:i + 512]
            w = _gate_weights(net(St[b]), topk)
            ens = torch.einsum("nk,nkc->nc", w, P[b])
            loss = F.nll_loss(torch.log(ens + 1e-9), yt[b])
            opt.zero_grad(); loss.backward(); opt.step()
        if loss.item() < best - 1e-4: best, bad = loss.item(), 0
        else:
            bad += 1
            if bad >= 10: break
    return net


def _gate_weights(logits, topk):
    if topk:
        v, i = logits.topk(topk, dim=-1)
        masked = torch.full_like(logits, float("-inf")).scatter(-1, i, v)
        return torch.softmax(masked, -1)
    return torch.softmax(logits, -1)


def predict_gate(net, S, device="cpu", topk=None):
    with torch.no_grad():
        return _gate_weights(net(torch.as_tensor(S, device=device)), topk).cpu().numpy()


def linucb(S, probs, y, K, Ste, alpha_ucb=0.5, cfg=None, seed=0):
    """Per-arm LinUCB over K arms (each arm = 'trust base learner k'); the
    played weight vector is one-hot-smoothed on the chosen arm. Reward = Eq. 13."""
    rng = np.random.default_rng(seed); d = S.shape[1]
    A = [np.eye(d) for _ in range(K)]; b = [np.zeros(d) for _ in range(K)]
    sub = rng.permutation(len(S))[:20000]                  # bandit trained on a subsample
    for i in sub:
        x = S[i].astype(np.float64)
        ucb = [x @ np.linalg.solve(A[k], b[k]) + alpha_ucb * np.sqrt(x @ np.linalg.solve(A[k], x)) for k in range(K)]
        k = int(np.argmax(ucb)); w = np.full(K, 0.1 / (K - 1)); w[k] = 0.9
        ens = sum(w[j] * probs[j][i] for j in range(K))[None]
        r = compute_reward(ens, y[i:i + 1], cfg["reward_confidence_weight"], 0.0)[0]
        A[k] += np.outer(x, x); b[k] += r * x
    theta = [np.linalg.solve(A[k], b[k]) for k in range(K)]
    arms = np.argmax(np.stack([Ste @ theta[k] for k in range(K)], 1), 1)
    W = np.full((len(Ste), K), 0.1 / (K - 1)); W[np.arange(len(Ste)), arms] = 0.9
    return W


def dqn(S, probs, y, K, Ste, cfg, seed, device="cpu", episodes=None, n_levels=3):
    """DQN over discretised simplex: actions = all K-vectors of multiples of 1/(n_levels) summing to 1."""
    set_seed(seed); episodes = episodes or cfg["training_episodes"]      # same 100 episodes as PPO (Table 5)
    acts = np.array([a for a in itertools.product(range(n_levels + 1), repeat=K) if sum(a) == n_levels], float) / n_levels
    q = nn.Sequential(nn.Linear(S.shape[1], 256), nn.ReLU(), nn.Linear(256, 128), nn.ReLU(), nn.Linear(128, len(acts))).to(device)
    opt = torch.optim.Adam(q.parameters(), lr=1e-3); St = torch.as_tensor(S, device=device)
    eps = 1.0; log = []
    for ep in range(episodes):
        perm = np.random.permutation(len(S))
        for i in range(0, len(S), 512):
            idx = perm[i:i + 512]
            with torch.no_grad(): qa = q(St[idx]).argmax(1).cpu().numpy()
            a = np.where(np.random.rand(len(idx)) < eps, np.random.randint(len(acts), size=len(idx)), qa)
            ens = ensemble(acts[a], [p[idx] for p in probs])
            r = torch.as_tensor(compute_reward(ens, y[idx], cfg["reward_confidence_weight"], cfg["reward_calibration_weight"]),
                                dtype=torch.float32, device=device)
            pred = q(St[idx]).gather(1, torch.as_tensor(a, device=device)[:, None]).squeeze(1)
            loss = F.mse_loss(pred, r); opt.zero_grad(); loss.backward(); opt.step()   # one-step (stateless) TD target = r
        eps = max(0.05, eps * 0.9)
        with torch.no_grad(): g = q(St).argmax(1).cpu().numpy()
        log.append(dict(episode=ep + 1, monitor_accuracy=float((ensemble(acts[g], probs).argmax(1) == y).mean())))
    with torch.no_grad(): best = q(torch.as_tensor(Ste, device=device)).argmax(1).cpu().numpy()
    return acts[best], log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True, choices=["lr_meta", "mlp_gating", "moe_gate_ce", "linucb", "dqn", "tabnet"])
    ap.add_argument("--dataset", default="cicids2017"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = ap.parse_args()
    cfg = load_yaml("config/ppo_hyperparams.yaml"); split = f"stratified_seed{a.seed}"
    if a.name == "tabnet":
        from .tabnet_variant import run_tabnet; return run_tabnet(a)
    val, test, yva, yte = get_base_probs(a.dataset, split, a.seed, a.device)
    K, C = len(val), val[0].shape[1]; Sv, St = state_for(val), state_for(test); set_seed(a.seed)
    if a.name == "lr_meta":
        from sklearn.linear_model import LogisticRegression
        m = LogisticRegression(max_iter=300).fit(Sv, yva)
        proba = np.zeros((len(St), C)); proba[:, m.classes_] = m.predict_proba(St); pred = proba.argmax(1)
    else:
        if a.name == "mlp_gating": W = predict_gate(train_gate(Sv, val, yva, K, 256, device=a.device), St, a.device)
        elif a.name == "moe_gate_ce": W = predict_gate(train_gate(Sv, val, yva, K, 128, device=a.device, topk=2), St, a.device, topk=2)
        elif a.name == "linucb": W = linucb(Sv, val, yva, K, St, cfg=cfg, seed=a.seed)
        else:
            W, dlog = dqn(Sv, val, yva, K, St, cfg, a.seed, a.device)
            os.makedirs(os.path.join(ROOT, "results", "logs"), exist_ok=True)
            json.dump(dlog, open(os.path.join(ROOT, "results", "logs", f"dqn_{a.dataset}_seed{a.seed}.json"), "w"), indent=1)
        pred = ensemble(W, test).argmax(1)
    rep = full_report(yte, pred, C); rep.update(ablation=a.name, seed=a.seed, dataset=a.dataset)
    out = os.path.join(ROOT, "results", "raw_per_seed", f"ablation_{a.dataset}_{a.name}_seed{a.seed}.json")
    json.dump(rep, open(out, "w"), indent=1); print(f"[{a.name} seed={a.seed}] acc={rep['accuracy']*100:.2f}")


if __name__ == "__main__":
    main()
