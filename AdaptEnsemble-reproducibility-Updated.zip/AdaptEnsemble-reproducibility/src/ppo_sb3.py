"""OPTIONAL cross-check with Stable-Baselines3 PPO (the manuscript lists SB3 2.2 in Section IV-A).

The default backend (src/ppo_agent.py + train_adaptensemble.py) is a batched PyTorch implementation of the
same equations (Eq. 12, 15-18, Table 1). SB3 steps a Python environment one instance at a time, so a full
100-episode run over ~566k validation instances is impractical; use --max-instances for a subset check.
SB3 has a single learning rate, so the critic uses the actor's 3e-4 here (Table 1: 1e-3).
NOT executed by the package authors. Usage: python -m src.ppo_sb3 --seed 0 --max-instances 50000

NOTE — ECE computation differs from the main backend:
  Main backend (reward.py): ECE computed over the full rollout-buffer mini-batch (256 instances, batch-level).
  This SB3 backend: ECE computed over a sliding window of the last 256 *individual* steps (WeightEnv.win).
  The sliding-window ECE is a per-step approximation that makes the reward Markovian; the batch ECE in the
  main backend is exact over the mini-batch. Both use M=15 bins and min_bin_samples=5 from ppo_hyperparams.yaml.
  Results from the two backends are therefore not directly comparable.
"""
import argparse, collections
import numpy as np
import gymnasium as gym
from gymnasium import spaces
from .common import get_base_probs, state_for, ensemble, load_yaml
from .reward import expected_calibration_error
from .evaluation.metrics import full_report


class WeightEnv(gym.Env):
    def __init__(self, S, probs, y, alpha, beta, bins, min_n, win=256):
        super().__init__(); self.S, self.P, self.y = S, np.stack(probs, 1), y
        self.alpha, self.beta, self.bins, self.min_n = alpha, beta, bins, min_n
        self.observation_space = spaces.Box(-np.inf, np.inf, (S.shape[1],), np.float32)
        self.action_space = spaces.Box(-np.inf, np.inf, (self.P.shape[1],), np.float32)
        self.win = collections.deque(maxlen=win); self.t = 0; self.order = None

    def reset(self, seed=None, options=None):
        super().reset(seed=seed); self.order = self.np_random.permutation(len(self.y)); self.t = 0
        return self.S[self.order[0]], {}

    def step(self, a):
        i = self.order[self.t]; w = np.exp(a - a.max()); w /= w.sum()
        p = (w[:, None] * self.P[i]).sum(0); pred = int(p.argmax())
        self.win.append((p[pred], pred == self.y[i]))
        conf, corr = np.array([c for c, _ in self.win]), np.array([k for _, k in self.win])
        ece = expected_calibration_error(conf, corr, self.bins, self.min_n)
        r = float(pred == self.y[i]) + self.alpha * p[self.y[i]] - self.beta * ece          # Eq. 13
        self.t += 1; done = self.t >= len(self.order)
        return self.S[self.order[min(self.t, len(self.order) - 1)]], r, done, False, {}


def main():
    from stable_baselines3 import PPO
    ap = argparse.ArgumentParser(); ap.add_argument("--dataset", default="cicids2017"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max-instances", type=int, default=50000); ap.add_argument("--episodes", type=int, default=1); a = ap.parse_args()
    cfg = load_yaml("config/ppo_hyperparams.yaml")
    val, test, yva, yte = get_base_probs(a.dataset, f"stratified_seed{a.seed}", a.seed)
    S = state_for(val)[:a.max_instances]; env = WeightEnv(S, [p[:a.max_instances] for p in val], yva[:a.max_instances],
                                                         cfg["reward_confidence_weight"], cfg["reward_calibration_weight"],
                                                         cfg["ece"]["num_bins"], cfg["ece"]["min_bin_samples"])
    model = PPO("MlpPolicy", env, n_steps=cfg["rollout_buffer_size"], n_epochs=cfg["ppo_update_epochs"], batch_size=256,
                gamma=cfg["discount_gamma"], gae_lambda=cfg["gae_lambda"], clip_range=cfg["clipping_epsilon"],
                ent_coef=cfg["entropy_bonus_coef"], vf_coef=cfg["value_loss_coef"], learning_rate=cfg["actor_learning_rate"],
                policy_kwargs=dict(net_arch=dict(pi=[256, 128], vf=[256, 128])), seed=a.seed, verbose=0)
    model.learn(total_timesteps=len(S) * a.episodes)
    St = state_for(test); act, _ = model.predict(St, deterministic=True)
    w = np.exp(act - act.max(1, keepdims=True)); w /= w.sum(1, keepdims=True)
    rep = full_report(yte, ensemble(w, test).argmax(1), val[0].shape[1]); print("SB3 PPO test accuracy:", rep["accuracy"])


if __name__ == "__main__":
    main()
