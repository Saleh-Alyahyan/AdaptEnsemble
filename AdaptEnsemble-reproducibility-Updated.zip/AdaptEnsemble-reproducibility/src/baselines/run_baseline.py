"""Table 10 baselines, re-implemented under the identical splits/preprocessing.
Hyperparameters come from config/baseline_configs/*.yaml.

NOTE: apart from DES-Oracle (DESlib), these are our own re-implementations from the
published descriptions (no original code was used), as stated in Section IV-G.

  stacking_dnn | adaecelm | cat_attn | des_oracle | moe_gate | marl_alloc
Usage: python -m src.baselines.run_baseline --name adaecelm --dataset cicids2017 --seed 0
"""
import argparse, json, os
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from ..common import get_base_probs, load_split, state_for, ensemble, load_yaml, set_seed, ROOT, num_classes_of
from ..evaluation.metrics import full_report
from ..ablations.run_ablation import train_gate, predict_gate
from ..ppo_agent import PolicyNetwork, ValueNetwork, compute_gae, ppo_clipped_loss, value_loss, total_loss
from ..reward import compute_reward


def adaecelm(val, yva, test, cfg, seed):
    """Evolutionary search over a fixed global weight vector (pop 50, 100 gens, crossover 0.8)."""
    rng = np.random.default_rng(seed); K = len(val)
    sub = rng.permutation(len(yva))[:50000]; vs = [p[sub] for p in val]
    fit = lambda w: (ensemble(np.tile(w, (len(sub), 1)), vs).argmax(1) == yva[sub]).mean()
    pop = rng.dirichlet(np.ones(K), cfg["population_size"])
    for _ in range(cfg["generations"]):
        f = np.array([fit(w) for w in pop]); pop = pop[np.argsort(-f)]
        elite = pop[: cfg["population_size"] // 2]; kids = []
        while len(kids) < cfg["population_size"] - len(elite):
            p1, p2 = elite[rng.integers(len(elite), size=2)]
            c = (p1 + p2) / 2 if rng.random() < cfg["crossover_rate"] else p1.copy()
            c = np.abs(c + rng.normal(0, 0.02, K)); kids.append(c / c.sum())
        pop = np.vstack([elite, kids])
    best = max(pop, key=fit)
    return ensemble(np.tile(best, (len(test[0]), 1)), test).argmax(1)


class AttnFusion(nn.Module):
    def __init__(self, K, C, d=128, heads=4):
        super().__init__(); self.emb = nn.Linear(C, d); self.attn = nn.MultiheadAttention(d, heads, batch_first=True)
        self.out = nn.Linear(d, C)
    def forward(self, P):                         # P: (N,K,C)
        h = self.emb(P); h, _ = self.attn(h, h, h); return self.out(h.mean(1))


def cat_attn(val, yva, test, cfg, seed, device):
    set_seed(seed); K, C = len(val), val[0].shape[1]
    net = AttnFusion(K, C, cfg["embedding_dim"], cfg["attention_heads"]).to(device)
    opt = torch.optim.Adam(net.parameters(), lr=cfg["learning_rate"])
    P = torch.as_tensor(np.stack(val, 1), dtype=torch.float32, device=device); y = torch.as_tensor(yva, device=device)
    best, bad = 0, 0
    for ep in range(100):
        perm = torch.randperm(len(P))
        for i in range(0, len(P), 512):
            b = perm[i:i + 512]; loss = F.cross_entropy(net(P[b]), y[b]); opt.zero_grad(); loss.backward(); opt.step()
        with torch.no_grad(): acc = (net(P[:20000]).argmax(1) == y[:20000]).float().mean().item()
        if acc > best: best, bad = acc, 0
        else:
            bad += 1
            if bad >= cfg["early_stopping"]["patience"]: break
    with torch.no_grad(): return net(torch.as_tensor(np.stack(test, 1), dtype=torch.float32, device=device)).argmax(1).cpu().numpy()


class _Wrap:
    """sklearn-style wrapper around pre-computed probabilities for DESlib."""
    def __init__(self, probs_by_idx, k, C): self.k, self.classes_, self.P = k, np.arange(C), probs_by_idx
    def predict_proba(self, X): return self.P[self.k][X[:, 0].astype(int)]
    def predict(self, X): return self.predict_proba(X).argmax(1)


def des_oracle(val, yva, test, cfg, seed):
    """DESlib KNORA-E (k=5). Features are replaced by row indices so the pool can serve cached
    probabilities; competence regions are computed on the (index,) space -> instead we use the
    confidence-vector concatenation as the region space via a lookup table."""
    from deslib.des import KNORAE
    K, C = len(val), val[0].shape[1]
    Xv = np.concatenate(val, 1); Xt = np.concatenate(test, 1)
    class W:
        def __init__(s, k): s.k = k; s.classes_ = np.arange(C)
        def predict_proba(s, X): return X[:, s.k * C:(s.k + 1) * C]
        def predict(s, X): return s.predict_proba(X).argmax(1)
    pool = [W(k) for k in range(K)]
    sub = np.random.default_rng(seed).permutation(len(yva))[:50000]
    des = KNORAE(pool_classifiers=pool, k=cfg["k_neighbors"]); des.fit(Xv[sub], yva[sub])
    return des.predict(Xt)


def moe_gate(val, yva, test, Sv, St, device):
    K = len(val); net = train_gate(Sv, val, yva, K, 128, device=device, topk=2)
    return ensemble(predict_gate(net, St, device, topk=2), test).argmax(1)


def marl_alloc(val, yva, test, Sv, St, cfg, seed, device, ppo_cfg):
    """MAPPO-style: K agents, each outputs a scalar logit for its own learner from the shared
    state (CTDE: one centralised critic). Joint weights = softmax(logits). Shared team reward."""
    set_seed(seed); K = len(val); d = Sv.shape[1]
    actors = [PolicyNetwork(d, 1).to(device) for _ in range(K)]; critic = ValueNetwork(d).to(device)
    opt = torch.optim.Adam([p for a in actors for p in a.parameters()] + list(critic.parameters()), lr=cfg["learning_rate"])
    S = torch.as_tensor(Sv, device=device)
    for ep in range(cfg["training_episodes"]):
        perm = np.random.permutation(len(S))
        for i in range(0, len(S), 2048):
            idx = perm[i:i + 2048]; s = S[idx]
            with torch.no_grad():
                outs = [a.sample_action(s) for a in actors]; vals = critic(s).cpu()
            raw = torch.cat([o[0] for o in outs], 1); old_lp = torch.stack([o[2] for o in outs], 1)
            w = torch.softmax(raw, -1).cpu().numpy()
            r = torch.as_tensor(compute_reward(ensemble(w, [p[idx] for p in val]), yva[idx], 0.3, 0.1), dtype=torch.float32)
            adv, ret = compute_gae(r, vals, 0.0, 0.99, 0.95); adv = ((adv - adv.mean()) / (adv.std() + 1e-8)).to(device)
            for _ in range(10):
                loss = 0
                for k, a in enumerate(actors):
                    loss = loss + ppo_clipped_loss(a.log_prob(s, raw[:, k:k + 1]), old_lp[:, k], adv, 0.2)
                loss = loss + 0.5 * value_loss(critic(s), ret.to(device))
                opt.zero_grad(); loss.backward(); opt.step()          # (decentralised execution at test time)
    with torch.no_grad():
        St_t = torch.as_tensor(St, device=device)
        mu = torch.cat([a(St_t)[0] for a in actors], 1); W = torch.softmax(mu, -1).cpu().numpy()
    return ensemble(W, test).argmax(1)


def stacking_dnn(dataset, seed, cfg, device, epochs=10):
    """LSTM(128) + GRU(128) level-0 learners on the raw feature sequence; MLP(256-128) meta-learner on their
    concatenated softmax outputs (trained on D_val)."""
    d = load_split(dataset, f"stratified_seed{seed}"); C = num_classes_of(d); set_seed(seed)
    def seq_model(cell):
        class M(nn.Module):
            def __init__(s):
                super().__init__(); s.r = cell(1, 128, batch_first=True); s.o = nn.Linear(128, C)
            def forward(s, x): h, _ = s.r(x.unsqueeze(-1)); return s.o(h[:, -1])
        return M().to(device)
    def fit(m, X, y, Xv, yv):
        opt = torch.optim.Adam(m.parameters(), lr=cfg["learning_rate"]); best, bad = 1e9, 0
        X, y = torch.as_tensor(X, dtype=torch.float32, device=device), torch.as_tensor(y, device=device)
        Xv, yv = torch.as_tensor(Xv[:20000], dtype=torch.float32, device=device), torch.as_tensor(yv[:20000], device=device)
        for ep in range(epochs):
            perm = torch.randperm(len(X))
            for i in range(0, len(X), 1024):
                b = perm[i:i + 1024]; l = F.cross_entropy(m(X[b]), y[b]); opt.zero_grad(); l.backward(); opt.step()
            with torch.no_grad(): vl = F.cross_entropy(m(Xv), yv).item()
            if vl < best: best, bad = vl, 0
            else:
                bad += 1
                if bad >= cfg["early_stopping"]["patience"]: break
        return m
    lstm = fit(seq_model(nn.LSTM), d["X_train"], d["y_train"], d["X_val"], d["y_val"])
    gru = fit(seq_model(nn.GRU), d["X_train"], d["y_train"], d["X_val"], d["y_val"])
    def feats(X):
        with torch.no_grad():
            out = []
            for i in range(0, len(X), 4096):
                x = torch.as_tensor(X[i:i + 4096], dtype=torch.float32, device=device)
                out.append(torch.cat([F.softmax(lstm(x), -1), F.softmax(gru(x), -1)], 1).cpu())
            return torch.cat(out).numpy()
    Fv, Ft = feats(d["X_val"]), feats(d["X_test"])
    meta = nn.Sequential(nn.Linear(2 * C, 256), nn.ReLU(), nn.Linear(256, 128), nn.ReLU(), nn.Linear(128, C)).to(device)
    opt = torch.optim.Adam(meta.parameters(), lr=cfg["learning_rate"])
    Fv_t, yv_t = torch.as_tensor(Fv, device=device), torch.as_tensor(d["y_val"], device=device)
    for ep in range(30):
        perm = torch.randperm(len(Fv_t))
        for i in range(0, len(Fv_t), 512):
            b = perm[i:i + 512]; l = F.cross_entropy(meta(Fv_t[b]), yv_t[b]); opt.zero_grad(); l.backward(); opt.step()
    with torch.no_grad(): return meta(torch.as_tensor(Ft, device=device)).argmax(1).cpu().numpy(), d["y_test"], C


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True, choices=["stacking_dnn", "adaecelm", "cat_attn", "des_oracle", "moe_gate", "marl_alloc"])
    ap.add_argument("--dataset", default="cicids2017"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = ap.parse_args(); cfg = load_yaml(f"config/baseline_configs/{a.name}.yaml"); ppo_cfg = load_yaml("config/ppo_hyperparams.yaml")
    if a.name == "stacking_dnn":
        pred, yte, C = stacking_dnn(a.dataset, a.seed, cfg, a.device)
    else:
        val, test, yva, yte = get_base_probs(a.dataset, f"stratified_seed{a.seed}", a.seed, a.device); C = val[0].shape[1]
        Sv, St = state_for(val), state_for(test)
        pred = {"adaecelm": lambda: adaecelm(val, yva, test, cfg, a.seed),
                "cat_attn": lambda: cat_attn(val, yva, test, cfg, a.seed, a.device),
                "des_oracle": lambda: des_oracle(val, yva, test, cfg, a.seed),
                "moe_gate": lambda: moe_gate(val, yva, test, Sv, St, a.device),
                "marl_alloc": lambda: marl_alloc(val, yva, test, Sv, St, cfg, a.seed, a.device, ppo_cfg)}[a.name]()
    rep = full_report(yte, pred, C); rep.update(baseline=a.name, seed=a.seed, dataset=a.dataset)
    out = os.path.join(ROOT, "results", "raw_per_seed", f"baseline_{a.dataset}_{a.name}_seed{a.seed}.json")
    json.dump(rep, open(out, "w"), indent=1); print(f"[{a.name} seed={a.seed}] acc={rep['accuracy']*100:.2f}")


if __name__ == "__main__":
    main()
