"""Table 2 rows: individual base learners and static / DES baselines on the same frozen outputs.

  individual:<name>  each of the five base learners alone
  majority_voting | avg_probability | weighted_voting (weights ∝ validation accuracy)
  stacking_lr  logistic-regression meta-learner on the concatenated confidence vectors
  des_knn      DESlib DES-KNN (k=7, DESlib default)
(DQN-Ensemble = `python -m src.ablations.run_ablation --name dqn`; same agent as the Table 4 DQN row.)
Usage: python -m src.baselines.static_ensembles --dataset cicids2017 --seed 0
"""
import argparse, json, os
import numpy as np
from ..common import get_base_probs, ORDER, ROOT
from ..evaluation.metrics import full_report


def run_all(val, yva, test, yte):
    K, C = len(val), val[0].shape[1]; out = {}
    for i, n in enumerate(ORDER):
        out[f"individual_{n}"] = test[i].argmax(1)
    votes = np.stack([p.argmax(1) for p in test], 1)
    out["majority_voting"] = np.array([np.bincount(v, minlength=C).argmax() for v in votes])
    out["avg_probability"] = np.mean(np.stack(test), 0).argmax(1)
    acc = np.array([(p.argmax(1) == yva).mean() for p in val]); w = acc / acc.sum()
    out["weighted_voting"] = np.tensordot(w, np.stack(test), 1).argmax(1)
    from sklearn.linear_model import LogisticRegression
    lr = LogisticRegression(max_iter=300).fit(np.concatenate(val, 1), yva)
    p = np.zeros((len(yte), C)); p[:, lr.classes_] = lr.predict_proba(np.concatenate(test, 1)); out["stacking_lr"] = p.argmax(1)
    try:
        from deslib.des import DESKNN
        class W:
            def __init__(s, k): s.k = k; s.classes_ = np.arange(C)
            def predict_proba(s, X): return X[:, s.k * C:(s.k + 1) * C]
            def predict(s, X): return s.predict_proba(X).argmax(1)
        Xv, Xt = np.concatenate(val, 1), np.concatenate(test, 1)
        sub = np.random.default_rng(0).permutation(len(yva))[:50000]
        des = DESKNN(pool_classifiers=[W(k) for k in range(K)]); des.fit(Xv[sub], yva[sub]); out["des_knn"] = des.predict(Xt)
    except Exception as e:                                      # DESlib/sklearn version issues
        print("des_knn skipped:", repr(e))
    return out, C


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--dataset", default="cicids2017"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", default="cpu"); a = ap.parse_args()
    val, test, yva, yte = get_base_probs(a.dataset, f"stratified_seed{a.seed}", a.seed, a.device)
    preds, C = run_all(val, yva, test, yte)
    for name, pred in preds.items():
        rep = full_report(yte, pred, C); rep.update(baseline=name, seed=a.seed, dataset=a.dataset)
        json.dump(rep, open(os.path.join(ROOT, "results", "raw_per_seed", f"static_{a.dataset}_{name}_seed{a.seed}.json"), "w"), indent=1)
        print(f"[{name} seed={a.seed}] acc={rep['accuracy']*100:.2f}")


if __name__ == "__main__":
    main()
