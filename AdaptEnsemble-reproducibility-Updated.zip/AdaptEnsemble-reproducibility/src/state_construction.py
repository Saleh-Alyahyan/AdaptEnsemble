"""State construction — manuscript Section III-C, Equations 5-11.

s(x) = [ f_conf(x) ; f_disagree(x) ; f_entropy(x) ]  in R^Ds

  f_conf(x)      : concatenated softmax confidence vectors from all K base
                    learners                                   (Eq. 5)
  f_disagree(x)  : pairwise Jensen-Shannon Divergence between each pair of
                    base learners' confidence distributions     (Eq. 6-8)
  f_entropy(x)   : per-base-learner prediction entropy           (Eq. 9-10)

Ds = K*C + C(K,2) + K
"""
import itertools
import numpy as np

EPS = 1e-12  # numerical floor to avoid log(0)


def jensen_shannon_divergence(p: np.ndarray, q: np.ndarray) -> np.ndarray:
    """JSD(p||q) = 0.5*KL(p||m) + 0.5*KL(q||m), m = 0.5*(p+q).  Eq. 6-7.
    p, q: (N, C) arrays of class probabilities. Returns (N,) JSD values."""
    p = np.clip(p, EPS, 1.0)
    q = np.clip(q, EPS, 1.0)
    m = 0.5 * (p + q)
    kl_pm = np.sum(p * np.log(p / m), axis=1)
    kl_qm = np.sum(q * np.log(q / m), axis=1)
    return 0.5 * kl_pm + 0.5 * kl_qm


def prediction_entropy(p: np.ndarray) -> np.ndarray:
    """H(p) = -sum_c p_c log(p_c).  Eq. 9. p: (N, C) -> returns (N,)."""
    p = np.clip(p, EPS, 1.0)
    return -np.sum(p * np.log(p), axis=1)


def build_state(base_learner_probs: list) -> np.ndarray:
    """
    Args:
        base_learner_probs: list of K arrays, each (N, C) — softmax
            confidence vectors from each of the K base learners, in a
            fixed, consistent order.

    Returns:
        (N, Ds) state matrix, Ds = K*C + C(K,2) + K.
    """
    K = len(base_learner_probs)
    N, C = base_learner_probs[0].shape

    # (i) Confidence features — Eq. 5
    f_conf = np.concatenate(base_learner_probs, axis=1)  # (N, K*C)

    # (ii) Disagreement features — Eq. 6-8, all K-choose-2 pairs
    disagree_cols = []
    for i, j in itertools.combinations(range(K), 2):
        disagree_cols.append(
            jensen_shannon_divergence(base_learner_probs[i], base_learner_probs[j])
        )
    f_disagree = np.stack(disagree_cols, axis=1) if disagree_cols else np.zeros((N, 0))

    # (iii) Entropy features — Eq. 9-10
    entropy_cols = [prediction_entropy(p) for p in base_learner_probs]
    f_entropy = np.stack(entropy_cols, axis=1)  # (N, K)

    state = np.concatenate([f_conf, f_disagree, f_entropy], axis=1)
    return state


def state_dim(K: int, C: int) -> int:
    """Ds = K*C + C(K,2) + K — matches config/cross_dataset_architectures.yaml."""
    from math import comb
    return K * C + comb(K, 2) + K
