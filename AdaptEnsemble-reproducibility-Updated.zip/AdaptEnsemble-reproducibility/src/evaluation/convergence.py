"""Table 5: PPO vs DQN convergence from the per-episode logs in results/logs/.
Episodes to reach 99% / 99.5% monitor (validation) accuracy, final accuracy, mean gradient-norm variance."""
import glob, json, os
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def first_ep(log, thr):
    for r in log:
        if r["monitor_accuracy"] >= thr: return r["episode"]
    return None


def summarize(pattern):
    logs = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(ROOT, "results", "logs", pattern)))]
    if not logs: return None
    row = {}
    for thr in (0.99, 0.995):
        e = [first_ep(l, thr) for l in logs]; ok = [x for x in e if x is not None]
        row[f"episodes_to_{thr*100:g}%"] = (f"{np.mean(ok):.1f} ± {np.std(ok, ddof=1) if len(ok) > 1 else 0:.1f}" if ok else "never") + f" (reached in {len(ok)}/{len(logs)} seeds)"
    fin = [l[-1]["monitor_accuracy"] * 100 for l in logs]; row["final_val_acc_%"] = f"{np.mean(fin):.2f} ± {np.std(fin, ddof=1) if len(fin) > 1 else 0:.2f}"
    gv = [np.mean([r.get("grad_norm_variance", np.nan) for r in l]) for l in logs]; row["mean_grad_norm_variance"] = float(np.nanmean(gv))
    return row


def main():
    res = {"PPO": summarize("main_cicids2017_none_seed*.json"), "DQN": summarize("dqn_cicids2017_seed*.json")}
    out = os.path.join(ROOT, "results", "aggregated", "table5_convergence.json")
    os.makedirs(os.path.dirname(out), exist_ok=True); json.dump(res, open(out, "w"), indent=1); print(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
