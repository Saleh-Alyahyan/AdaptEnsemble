"""Paired t-tests across seeds (Section IV-G) and mean/std aggregation."""
import numpy as np
from scipy.stats import ttest_rel


def paired_t(a_per_seed, b_per_seed):
    t, p = ttest_rel(a_per_seed, b_per_seed)
    return float(t), float(p)


def mean_std(values):
    v = np.asarray(values, dtype=float)
    return float(v.mean()), float(v.std(ddof=1)) if len(v) > 1 else 0.0
