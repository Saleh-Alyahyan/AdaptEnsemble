"""Paired t-tests of AdaptEnsemble vs baselines/ablations across seeds (same seed order)."""
import glob, json, os, re
from .statistical_tests import paired_t
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def accs(pattern):
    fs = sorted(glob.glob(os.path.join(ROOT, "results", "raw_per_seed", pattern)),
                key=lambda f: int(re.search(r"seed(\d+)", f).group(1)))
    return [json.load(open(f))["accuracy"] * 100 for f in fs]


def main():
    ours = accs("main_cicids2017_none_seed*.json"); rows = []
    for name, pat in [("MARL-Alloc", "baseline_cicids2017_marl_alloc_seed*.json"),
                      ("DES-Oracle", "baseline_cicids2017_des_oracle_seed*.json"),
                      ("MoE-Gate", "baseline_cicids2017_moe_gate_seed*.json"),
                      ("MLP gating", "ablation_cicids2017_mlp_gating_seed*.json"),
                      ("MoE gate (CE)", "ablation_cicids2017_moe_gate_ce_seed*.json"),
                      ("Contextual bandit", "ablation_cicids2017_linucb_seed*.json"),
                      ("LR meta-learner", "ablation_cicids2017_lr_meta_seed*.json")]:
        b = accs(pat)
        if len(b) == len(ours) > 1:
            t, p = paired_t(ours, b); rows.append(f"{name}: t={t:.2f}, p={p:.4f}")
    out = os.path.join(ROOT, "results", "aggregated", "paired_ttests.txt")
    os.makedirs(os.path.dirname(out), exist_ok=True); open(out, "w").write("\n".join(rows)); print("\n".join(rows))


if __name__ == "__main__":
    main()
