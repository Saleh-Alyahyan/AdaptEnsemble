"""Metrics: weighted acc/prec/rec/F1 (Eq. 20-21), macro-F1, balanced accuracy,
per-class P/R/F1, and Clopper-Pearson exact confidence intervals."""
import numpy as np
from scipy.stats import beta
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                             balanced_accuracy_score, f1_score, confusion_matrix)


def clopper_pearson(k, n, alpha=0.05):
    """Exact two-sided (1-alpha) interval for a binomial proportion k/n."""
    if n == 0:
        return (float("nan"), float("nan"))
    lo = 0.0 if k == 0 else beta.ppf(alpha / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta.ppf(1 - alpha / 2, k + 1, n - k)
    return float(lo), float(hi)


def full_report(y_true, y_pred, num_classes):
    labels = list(range(num_classes))
    p, r, f, s = precision_recall_fscore_support(y_true, y_pred, labels=labels,
                                                 zero_division=0)
    wp, wr, wf, _ = precision_recall_fscore_support(y_true, y_pred, average="weighted",
                                                    zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    per_class = {}
    for c in labels:
        tp = int(cm[c, c]); n = int(cm[c].sum())
        lo, hi = clopper_pearson(tp, n)
        per_class[c] = dict(precision=float(p[c]), recall=float(r[c]), f1=float(f[c]),
                            support=int(s[c]), tp=tp, fn=n - tp,
                            fp=int(cm[:, c].sum() - tp), recall_ci95=[lo, hi])
    return dict(confusion_matrix=cm.tolist(), accuracy=float(accuracy_score(y_true, y_pred)),
                precision_weighted=float(wp), recall_weighted=float(wr), f1_weighted=float(wf),
                macro_f1=float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
                balanced_accuracy=float(balanced_accuracy_score(y_true, y_pred)),
                per_class=per_class)
