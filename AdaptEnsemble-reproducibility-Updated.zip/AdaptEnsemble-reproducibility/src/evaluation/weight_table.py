"""Table 6 / Fig. 7: mean ensemble weight per base learner per class, averaged over seeds."""
import glob, json, os
import numpy as np
from ..common import ORDER
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main():
    runs = [json.load(open(f)) for f in glob.glob(os.path.join(ROOT, "results", "raw_per_seed", "main_cicids2017_none_seed*.json"))]
    if not runs: print("no main runs found"); return
    classes = sorted({int(c) for r in runs for c in r["mean_weight_per_class"]})
    lines = ["class_idx," + ",".join(ORDER)]
    for c in classes:
        m = np.mean([r["mean_weight_per_class"][str(c)] for r in runs if str(c) in r["mean_weight_per_class"]], 0)
        lines.append(f"{c}," + ",".join(f"{x:.3f}" for x in m))
    lines.append("global," + ",".join(f"{x:.3f}" for x in np.mean([r["mean_weight_global"] for r in runs], 0)))
    out = os.path.join(ROOT, "results", "aggregated", "table6_weights.csv"); open(out, "w").write("\n".join(lines)); print("\n".join(lines))


if __name__ == "__main__":
    main()
