"""Aggregate results/raw_per_seed/*.json into mean +/- std CSV (and minority-class CIs)."""
import glob, json, os, re, csv
from collections import defaultdict
from .statistical_tests import mean_std
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main():
    groups = defaultdict(list)
    for f in glob.glob(os.path.join(ROOT, "results", "raw_per_seed", "*_seed*.json")):
        key = re.sub(r"_seed\d+\.json$", "", os.path.basename(f))
        groups[key].append(json.load(open(f)))
    out = os.path.join(ROOT, "results", "aggregated"); os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "summary_mean_std.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["experiment", "n_seeds", "metric", "mean_pct", "std_pct"])
        for k, runs in sorted(groups.items()):
            for m in ["accuracy", "precision_weighted", "recall_weighted", "f1_weighted",
                      "macro_f1", "balanced_accuracy"]:
                vals = [r[m] * 100 for r in runs if m in r]
                if vals:
                    mu, sd = mean_std(vals); w.writerow([k, len(vals), m, f"{mu:.2f}", f"{sd:.2f}"])
    with open(os.path.join(out, "confidence_intervals.csv"), "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(["experiment", "seed_file_idx", "class", "support", "tp", "fn", "recall_ci_lo", "recall_ci_hi"])
        for k, runs in sorted(groups.items()):
            for i, r in enumerate(runs):
                for c, d in r.get("per_class", {}).items():
                    if 0 < d["support"] <= 10:
                        w.writerow([k, i, c, d["support"], d["tp"], d["fn"], *[f"{x:.4f}" for x in d["recall_ci95"]]])
    print("Wrote", out)


if __name__ == "__main__":
    main()
