"""Reward function — manuscript Section III-C, Equations 13-14.

r(s, a, y) = 1[y_hat(x) = y]                      correctness
           + alpha * p_hat_y(x)                    confidence bonus
           - beta  * L_ECE(p)                       calibration penalty

L_ECE computed with M=15 equal-width confidence bins over [0,1]; bins with
fewer than 5 samples (within a mini-batch) are excluded from the ECE sum
to avoid unstable estimates for minority classes (response to Reviewer 1
Minor Comment 5).
"""
import numpy as np


def expected_calibration_error(confidences: np.ndarray, correct: np.ndarray,
                                num_bins: int = 15, min_bin_samples: int = 5) -> float:
    """
    Args:
        confidences: (N,) the ensemble's predicted probability for its
            top (predicted) class, per instance.
        correct: (N,) boolean array, whether that prediction was correct.
        num_bins: M, number of equal-width bins over [0, 1].
        min_bin_samples: bins with fewer samples than this are excluded.

    Returns:
        scalar ECE value.
    """
    bin_edges = np.linspace(0.0, 1.0, num_bins + 1)
    n = len(confidences)
    ece = 0.0
    for b in range(num_bins):
        lo, hi = bin_edges[b], bin_edges[b + 1]
        in_bin = (confidences > lo) & (confidences <= hi) if b > 0 else (confidences >= lo) & (confidences <= hi)
        bin_count = in_bin.sum()
        if bin_count < min_bin_samples:
            continue  # excluded — see docstring
        bin_acc = correct[in_bin].mean()
        bin_conf = confidences[in_bin].mean()
        ece += (bin_count / n) * abs(bin_acc - bin_conf)
    return float(ece)


def compute_reward(ensemble_probs: np.ndarray, y_true: np.ndarray,
                    alpha: float = 0.30, beta: float = 0.10,
                    ece_num_bins: int = 15, ece_min_bin_samples: int = 5) -> np.ndarray:
    """
    Args:
        ensemble_probs: (N, C) the ensemble's predicted class-probability
            vector p(x) (Eq. 2) for each instance in a mini-batch.
        y_true: (N,) integer ground-truth labels.
        alpha, beta: reward composition hyperparameters (Table 1).

    Returns:
        (N,) per-instance reward (the calibration penalty term is a
        batch-level scalar broadcast across all N instances in the
        mini-batch, per Section III-C's dual-level reward design).
    """
    N = ensemble_probs.shape[0]
    y_pred = np.argmax(ensemble_probs, axis=1)
    correct = (y_pred == y_true)

    correctness = correct.astype(np.float64)                       # 1[y_hat = y]
    p_true_class = ensemble_probs[np.arange(N), y_true]             # p_hat_y(x)
    confidence_bonus = alpha * p_true_class

    top_confidence = ensemble_probs[np.arange(N), y_pred]           # for ECE binning
    ece = expected_calibration_error(
        top_confidence, correct, num_bins=ece_num_bins, min_bin_samples=ece_min_bin_samples
    )
    calibration_penalty = beta * ece  # batch-level scalar, broadcast below

    reward = correctness + confidence_bonus - calibration_penalty
    return reward
