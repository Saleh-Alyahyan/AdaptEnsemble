"""PPO agent — manuscript Section III-D (PPO Agent Architecture), Eq 12, 15-19.

Policy network (actor): Ds-256-128-K, outputs a Gaussian over raw logits,
    passed through softmax (Eq. 12) to yield a valid weight simplex.
Value network (critic): Ds-256-128-1.
Clipped surrogate objective (Eq. 16), GAE (Eq. 17), combined loss (Eq. 18).

Hyperparameters are read from config/ppo_hyperparams.yaml (Table 1) by the
caller (train_adaptensemble.py); this module exposes the architectures and
loss computation only.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal


class PolicyNetwork(nn.Module):
    """Actor: Ds-256-128-K, outputs mean and (state-independent) log-std
    of a diagonal Gaussian over the K-dim raw action/logit vector (Eq. 15)."""

    def __init__(self, state_dim: int, num_base_learners: int):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Linear(state_dim, 256), nn.ReLU(),
            nn.Linear(256, 128), nn.ReLU(),
        )
        self.mean_head = nn.Linear(128, num_base_learners)
        self.log_std = nn.Parameter(torch.zeros(num_base_learners))

    def forward(self, state):
        h = self.backbone(state)
        mean = self.mean_head(h)
        std = torch.exp(self.log_std).expand_as(mean)
        return mean, std

    def sample_action(self, state):
        mean, std = self.forward(state)
        dist = Normal(mean, std)
        raw_action = dist.rsample()
        log_prob = dist.log_prob(raw_action).sum(dim=-1)
        weights = F.softmax(raw_action, dim=-1)  # Eq. 12
        return raw_action, weights, log_prob

    def log_prob(self, state, raw_action):
        mean, std = self.forward(state)
        dist = Normal(mean, std)
        return dist.log_prob(raw_action).sum(dim=-1)


class ValueNetwork(nn.Module):
    """Critic: Ds-256-128-1, estimates V_phi(s)."""

    def __init__(self, state_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 256), nn.ReLU(),
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, 1),
        )

    def forward(self, state):
        return self.net(state).squeeze(-1)


def compute_gae(rewards, values, next_value, gamma: float, lam: float):
    """Generalized Advantage Estimate — Eq. 17.
    rewards, values: 1D tensors over a single episode's trajectory (length T).
    next_value: bootstrap value for the step after the trajectory (0 if terminal).
    Returns: (advantages, returns), both length T."""
    T = len(rewards)
    advantages = torch.zeros(T)
    gae = 0.0
    values_ext = torch.cat([values, torch.tensor([next_value])])
    for t in reversed(range(T)):
        delta = rewards[t] + gamma * values_ext[t + 1] - values_ext[t]
        gae = delta + gamma * lam * gae
        advantages[t] = gae
    returns = advantages + values
    return advantages, returns


def ppo_clipped_loss(new_log_probs, old_log_probs, advantages, epsilon: float):
    """Clipped surrogate objective — Eq. 16."""
    ratio = torch.exp(new_log_probs - old_log_probs)
    unclipped = ratio * advantages
    clipped = torch.clamp(ratio, 1 - epsilon, 1 + epsilon) * advantages
    return -torch.mean(torch.min(unclipped, clipped))


def value_loss(values_pred, returns):
    """L_VF — mean squared error term in Eq. 18."""
    return F.mse_loss(values_pred, returns)


def entropy_bonus(policy: PolicyNetwork, state):
    """H(pi_theta) — encourages exploration, Eq. 18."""
    mean, std = policy.forward(state)
    dist = Normal(mean, std)
    return dist.entropy().sum(dim=-1).mean()


def total_loss(clip_loss, v_loss, entropy, c1: float, c2: float):
    """Eq. 18 is a maximization objective: L = L_CLIP - c1*L_VF + c2*H.
    `clip_loss` returned by ppo_clipped_loss is already -L_CLIP (a loss to
    minimize), so the minimization form is: -L = clip_loss + c1*L_VF - c2*H."""
    return clip_loss + c1 * v_loss - c2 * entropy
