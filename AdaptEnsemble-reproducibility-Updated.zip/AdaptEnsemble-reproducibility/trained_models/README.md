# trained_models/
Frozen checkpoints are not included in this release. Base-learner outputs are cached under `data/cache/`
after the first run; add exported model files here once training has been completed.
