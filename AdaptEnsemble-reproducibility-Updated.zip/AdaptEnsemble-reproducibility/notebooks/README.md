# notebooks/
Optional. Load `results/aggregated/*.csv` and `results/logs/*.json` to regenerate tables/figures
(convergence curves: `results/logs/main_*_seed*.json`, field `mean_reward` per episode).
