# AdaptEnsemble — Reproducibility Package

Code, preprocessing, configuration and evaluation tooling for the manuscript
*Reinforcement Learning-Driven Dynamic Weight Allocation for High-Performance Heterogeneous Model Ensembles*
(submitted to *Computers, Materials & Continua*). Provided in response to Reviewer 2 (Comment 6) and Reviewer 1 (Major Concern 5).

**Read `CONSISTENCY.md` first.** It lists, item by item, where this code follows the manuscript exactly, where the
manuscript is silent and a choice had to be made, and where the manuscript's own numbers need to be re-checked
against a real run.

## What is and is not in this repository

| Included | Not included (must be produced by running the code) |
|---|---|
| Full pipeline: preprocessing → 5 base learners → state/reward/PPO → evaluation | `results/raw_per_seed/*.json` (per-seed outputs) |
| Every table/figure has a script (map below) | `trained_models/` checkpoints (written on first run) |
| Hyperparameters from Table 1 and Section III-B as YAML | The three datasets (public; download links below) |

No result in this repository is pre-filled. All numbers must come from running the experiments.

## Setup
```bash
python3.10 -m venv venv && source venv/bin/activate
pip install -r requirements.txt     # versions per manuscript Section IV-A
```
Reference hardware in the manuscript: RTX 4090 (24 GB), i9-13900K, 64 GB RAM.

## Data
| Dataset | Source |
|---|---|
| CICIDS2017 | https://www.unb.ca/cic/datasets/ids-2017.html |
| NSL-KDD | https://www.unb.ca/cic/datasets/nsl.html |
| UNSW-NB15 | https://research.unsw.edu.au/projects/unsw-nb15-dataset |

See `data/README_data.md` for file names. Then: `bash preprocessing/run_preprocessing.sh`.

## Run
```bash
bash experiments/run_all.sh        # everything, or the per-table scripts below
```
Five seeds (0, 42, 123, 456, 789) from `config/seeds.yaml`. First do a one-seed smoke test:
`python -m src.train_adaptensemble --dataset cicids2017 --seed 0 --episodes 2`.

## Manuscript → code map
| Manuscript item | Script / module |
|---|---|
| Sec. III-B base learners; Sec. III-B imbalance disclosure | `src/base_learners/`, `config/base_learner_configs.yaml` |
| Eq. 5–11 state (Ds = 90 / 40 / 65) | `src/state_construction.py` |
| Eq. 13–14 reward, ECE (M = 15, min 5 samples) | `src/reward.py` |
| Eq. 12, 15–19 PPO; Table 1 | `src/ppo_agent.py`, `config/ppo_hyperparams.yaml` |
| Algorithm 1 | `src/train_adaptensemble.py` |
| Sec. IV-A split, preprocessing | `preprocessing/` |
| Sec. IV-A grid search (validation only) | `experiments/run_hparam_search.sh`, `src/hparam_search.py` |
| Sec. IV-A nested D_pol / D_sel check | `--nested-split` in `run_ablations.sh` |
| Tables 2–3, Fig. 3–4 | `run_main_experiment.sh` (`src/baselines/static_ensembles.py`) |
| macro-F1, balanced accuracy, per-class CIs, confusion matrix | `src/evaluation/metrics.py` |
| Table 4 ablations | `run_ablations.sh`, `src/ablations/` |
| Table 5 convergence | `src/evaluation/convergence.py` |
| Table 6 / Fig. 7 weights | `src/evaluation/weight_table.py` |
| Tables 7–8 / Fig. 8 sensitivity | `run_sensitivity_analysis.sh` |
| Table 9 + CPU latency, memory, training time (Sec. IV-H) | `run_overhead_analysis.sh` |
| Table 10 baselines + paired t-tests (Sec. IV-I) | `run_baselines.sh`, `src/baselines/`, `src/evaluation/run_ttests.py` |
| Table 11 cross-dataset (Sec. IV-J) | `run_cross_dataset.sh` |
| Day-wise chronological split (Sec. IV-K) | `run_chronological_split.sh` |

## Testing status
Verified by execution (synthetic CICIDS-shaped data): preprocessing incl. the chronological split, label handling
when classes are absent from D_train, tree-model training/remapping, static ensembles, metrics (incl. Clopper-Pearson),
aggregation, and Ds = 90/40/65. **Not executed**: everything that needs PyTorch (MLP/1D-CNN, PPO, DQN, gating,
MARL, overhead, SB3 cross-check) — PyTorch could not be installed in the authoring sandbox. Run the smoke test above
and report any failure as an issue before relying on the results.

## Known limitations (as disclosed in the manuscript)
Per-class precision/recall/F1 and full ablations for NSL-KDD and UNSW-NB15 are not yet produced by the cross-dataset
script (aggregate metrics only).

## License / citation
`LICENSE` (replace placeholder names), `CITATION.cff`.
