"""
Preprocessing pipeline for CICIDS2017, matching manuscript Section IV-A:

  (1) removal of records with missing or infinite values (~0.3% of total)
  (2) removal of duplicate records
  (3) standardization of all 78 numerical features to zero mean / unit
      variance using StandardScaler fit on the training partition only
  (4) label encoding of the 15-class target variable

Produces a stratified 60/20/20 train/validation/test split (Section IV-A)
as well as the day-wise chronological split used in the "Day-wise
Chronological Evaluation" subsection (Monday+Tuesday=train, Wednesday=val,
Thursday+Friday=test).
"""
import argparse
import glob
import os

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

DAY_FILES = {
    "monday": "Monday-WorkingHours.pcap_ISCX.csv",
    "tuesday": "Tuesday-WorkingHours.pcap_ISCX.csv",
    "wednesday": "Wednesday-workingHours.pcap_ISCX.csv",
    "thursday_morning": "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",
    "thursday_afternoon": "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",
    "friday_morning": "Friday-WorkingHours-Morning.pcap_ISCX.csv",
    "friday_afternoon_portscan": "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",
    "friday_afternoon_ddos": "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",
}

LABEL_COLUMN = "Label"  # CICFlowMeter's canonical label column name


def load_raw(raw_dir: str) -> dict:
    """Loads each day's CSV into its own DataFrame (needed for the
    chronological split; the stratified split concatenates all of them)."""
    frames = {}
    for day, fname in DAY_FILES.items():
        path = os.path.join(raw_dir, fname)
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"Expected {fname} under {raw_dir}. See data/README_data.md."
            )
        df = pd.read_csv(path, low_memory=False)
        df.columns = [c.strip() for c in df.columns]
        frames[day] = df
    return frames


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Steps (1) and (2): drop missing/infinite rows and duplicates."""
    df = df.replace([np.inf, -np.inf], np.nan)
    before = len(df)
    df = df.dropna()
    df = df.drop_duplicates()
    removed_frac = 1 - len(df) / before if before else 0.0
    print(f"  removed {removed_frac:.4%} of rows (missing/infinite/duplicate)")
    return df


def encode_and_scale(train_df, val_df, test_df):
    """Steps (3) and (4). Scaler fit on train only, to avoid leakage."""
    feature_cols = [c for c in train_df.columns if c != LABEL_COLUMN]

    # Fit the label encoder on ALL labels (train+val+test) so that every split uses the same
    # C=15 columns. Required for the day-wise split, where test attack classes never appear in
    # D_train. (Labels carry no feature information, so this does not leak.)
    label_enc = LabelEncoder()
    label_enc.fit(pd.concat([train_df[LABEL_COLUMN], val_df[LABEL_COLUMN], test_df[LABEL_COLUMN]]))

    scaler = StandardScaler()
    scaler.fit(train_df[feature_cols])

    def _apply(df):
        X = scaler.transform(df[feature_cols])
        y = label_enc.transform(df[LABEL_COLUMN])
        return X, y

    X_train, y_train = _apply(train_df)
    X_val, y_val = _apply(val_df)
    X_test, y_test = _apply(test_df)

    return (X_train, y_train), (X_val, y_val), (X_test, y_test), label_enc, scaler


def build_stratified_split(frames: dict, seed: int):
    """60/20/20 stratified split used for Tables 2, 3, 4, 10 (Section IV-A)."""
    full = pd.concat(frames.values(), ignore_index=True)
    print(f"  raw records: {len(full):,}")
    full = clean(full)
    print(f"  records after cleaning: {len(full):,}")

    train_df, temp_df = train_test_split(
        full, test_size=0.4, stratify=full[LABEL_COLUMN], random_state=seed
    )
    val_df, test_df = train_test_split(
        temp_df, test_size=0.5, stratify=temp_df[LABEL_COLUMN], random_state=seed
    )
    return train_df, val_df, test_df


def build_chronological_split(frames: dict):
    """Day-wise split: Mon+Tue=train, Wed=val, Thu+Fri=test
    (Day-wise Chronological Evaluation subsection)."""
    train_df = pd.concat([frames["monday"], frames["tuesday"]], ignore_index=True)
    val_df = frames["wednesday"].copy()
    test_df = pd.concat(
        [
            frames["thursday_morning"],
            frames["thursday_afternoon"],
            frames["friday_morning"],
            frames["friday_afternoon_portscan"],
            frames["friday_afternoon_ddos"],
        ],
        ignore_index=True,
    )
    train_df = clean(train_df)
    val_df = clean(val_df)
    test_df = clean(test_df)
    return train_df, val_df, test_df


def save_split(out_dir, name, X_train, y_train, X_val, y_val, X_test, y_test, label_enc=None):
    os.makedirs(out_dir, exist_ok=True)
    extra = {}
    if label_enc is not None:
        extra = dict(num_classes=len(label_enc.classes_), class_names=label_enc.classes_.astype(str))
    np.savez_compressed(
        os.path.join(out_dir, f"{name}.npz"),
        X_train=X_train, y_train=y_train,
        X_val=X_val, y_val=y_val,
        X_test=X_test, y_test=y_test, **extra,
    )
    print(f"  saved {name}.npz -> {out_dir}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", default="data/raw/cicids2017")
    parser.add_argument("--out-dir", default="data/processed/cicids2017")
    parser.add_argument("--seed", type=int, default=0,
                         help="Seed for the stratified split (run once per "
                              "seed in config/seeds.yaml).")
    parser.add_argument("--mode", choices=["stratified", "chronological", "both"],
                         default="both")
    args = parser.parse_args()

    frames = load_raw(args.raw_dir)

    if args.mode in ("stratified", "both"):
        print(f"Building stratified 60/20/20 split (seed={args.seed})...")
        train_df, val_df, test_df = build_stratified_split(frames, args.seed)
        (X_tr, y_tr), (X_va, y_va), (X_te, y_te), enc, _ = encode_and_scale(
            train_df, val_df, test_df
        )
        save_split(args.out_dir, f"stratified_seed{args.seed}",
                   X_tr, y_tr, X_va, y_va, X_te, y_te, enc)

    if args.mode in ("chronological", "both"):
        print("Building day-wise chronological split...")
        train_df, val_df, test_df = build_chronological_split(frames)
        (X_tr, y_tr), (X_va, y_va), (X_te, y_te), enc, _ = encode_and_scale(
            train_df, val_df, test_df
        )
        save_split(args.out_dir, "chronological",
                   X_tr, y_tr, X_va, y_va, X_te, y_te, enc)
        missing = sorted(set(range(len(enc.classes_))) - set(np.unique(y_tr)))
        print("  classes absent from the chronological D_train:", [enc.classes_[i] for i in missing])


if __name__ == "__main__":
    main()
