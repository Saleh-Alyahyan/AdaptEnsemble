"""
Preprocessing pipeline for NSL-KDD, matching the "Cross-Dataset
Generalization Evaluation" subsection: identical preprocessing pipeline
to CICIDS2017 (missing-value removal, duplicate removal, StandardScaler,
label encoding) and the same 60/20/20 stratified split, applied to NSL-KDD's
41 features and 5 classes (Normal, DoS, Probe, R2L, U2R).
"""
import argparse
import os

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

# NSL-KDD has no header row; standard 41-feature + label + difficulty schema
COLUMN_NAMES = [
    "duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes",
    "land", "wrong_fragment", "urgent", "hot", "num_failed_logins",
    "logged_in", "num_compromised", "root_shell", "su_attempted", "num_root",
    "num_file_creations", "num_shells", "num_access_files", "num_outbound_cmds",
    "is_host_login", "is_guest_login", "count", "srv_count", "serror_rate",
    "srv_serror_rate", "rerror_rate", "srv_rerror_rate", "same_srv_rate",
    "diff_srv_rate", "srv_diff_host_rate", "dst_host_count",
    "dst_host_srv_count", "dst_host_same_srv_rate", "dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate",
    "dst_host_serror_rate", "dst_host_srv_serror_rate",
    "dst_host_rerror_rate", "dst_host_srv_rerror_rate",
    "label", "difficulty",
]

ATTACK_TO_CATEGORY = {
    "normal": "Normal",
    # DoS
    "back": "DoS", "land": "DoS", "neptune": "DoS", "pod": "DoS",
    "smurf": "DoS", "teardrop": "DoS", "apache2": "DoS", "udpstorm": "DoS",
    "processtable": "DoS", "worm": "DoS", "mailbomb": "DoS",
    # Probe
    "ipsweep": "Probe", "nmap": "Probe", "portsweep": "Probe",
    "satan": "Probe", "mscan": "Probe", "saint": "Probe",
    # R2L
    "ftp_write": "R2L", "guess_passwd": "R2L", "imap": "R2L",
    "multihop": "R2L", "phf": "R2L", "spy": "R2L", "warezclient": "R2L",
    "warezmaster": "R2L", "sendmail": "R2L", "named": "R2L",
    "snmpgetattack": "R2L", "snmpguess": "R2L", "xlock": "R2L",
    "xsnoop": "R2L", "httptunnel": "R2L",
    # U2R
    "buffer_overflow": "U2R", "loadmodule": "U2R", "perl": "U2R",
    "rootkit": "U2R", "ps": "U2R", "sqlattack": "U2R", "xterm": "U2R",
}


def load_raw(train_path: str, test_path: str) -> pd.DataFrame:
    train = pd.read_csv(train_path, names=COLUMN_NAMES)
    test = pd.read_csv(test_path, names=COLUMN_NAMES)
    full = pd.concat([train, test], ignore_index=True)
    full = full.drop(columns=["difficulty"])
    full["category"] = full["label"].str.strip().str.lower().map(
        lambda lbl: ATTACK_TO_CATEGORY.get(lbl, "Unknown")
    )
    unknown = (full["category"] == "Unknown").sum()
    if unknown:
        print(f"  warning: {unknown} rows had an unmapped attack label; "
              f"check ATTACK_TO_CATEGORY for completeness")
    return full.drop(columns=["label"])


def clean(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    df = df.drop_duplicates()
    print(f"  removed {1 - len(df) / before:.4%} of rows")
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-file", default="data/raw/nsl_kdd/KDDTrain+.txt")
    parser.add_argument("--test-file", default="data/raw/nsl_kdd/KDDTest+.txt")
    parser.add_argument("--out-dir", default="data/processed/nsl_kdd")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    full = load_raw(args.train_file, args.test_file)
    full = clean(full)

    # Ordinal-encode the 3 categorical columns so the model sees exactly the 41 raw features
    # stated in the manuscript (MLP input 41, Ds = 25+10+5 = 40).
    for c in ["protocol_type", "service", "flag"]:
        full[c] = full[c].astype("category").cat.codes

    feature_cols = [c for c in full.columns if c != "category"]

    train_df, temp_df = train_test_split(
        full, test_size=0.4, stratify=full["category"], random_state=args.seed
    )
    val_df, test_df = train_test_split(
        temp_df, test_size=0.5, stratify=temp_df["category"], random_state=args.seed
    )

    scaler = StandardScaler().fit(train_df[feature_cols])
    label_enc = LabelEncoder().fit(full["category"])

    def _apply(df):
        X = scaler.transform(df[feature_cols])
        y = label_enc.transform(df["category"])
        return X, y

    X_tr, y_tr = _apply(train_df)
    X_va, y_va = _apply(val_df)
    X_te, y_te = _apply(test_df)

    os.makedirs(args.out_dir, exist_ok=True)
    out_path = os.path.join(args.out_dir, f"stratified_seed{args.seed}.npz")
    np.savez_compressed(out_path, X_train=X_tr, y_train=y_tr,
                         X_val=X_va, y_val=y_va, X_test=X_te, y_test=y_te,
                         num_classes=len(label_enc.classes_), class_names=label_enc.classes_.astype(str))
    print(f"Saved -> {out_path}  (features={X_tr.shape[1]}, classes={len(label_enc.classes_)})")
    assert X_tr.shape[1] == 41, f"expected 41 features, got {X_tr.shape[1]}"


if __name__ == "__main__":
    main()
