#!/usr/bin/env bash
# Runs preprocessing for all three datasets, across all five seeds for
# CICIDS2017 (needed because its stratified split is regenerated per seed;
# NSL-KDD/UNSW-NB15 follow the same per-seed convention for consistency).
set -euo pipefail
cd "$(dirname "$0")/.."

SEEDS=(0 42 123 456 789)

echo "=== CICIDS2017 ==="
for seed in "${SEEDS[@]}"; do
    python preprocessing/preprocess_cicids2017.py --seed "${seed}" --mode stratified
done
python preprocessing/preprocess_cicids2017.py --mode chronological

echo "=== NSL-KDD ==="
for seed in "${SEEDS[@]}"; do
    python preprocessing/preprocess_nsl_kdd.py --seed "${seed}"
done

echo "=== UNSW-NB15 ==="
for seed in "${SEEDS[@]}"; do
    python preprocessing/preprocess_unsw_nb15.py --seed "${seed}"
done

echo "Preprocessing complete. Processed splits written under data/processed/."
