"""
Preprocessing pipeline for UNSW-NB15, matching the "Cross-Dataset
Generalization Evaluation" subsection: identical pipeline to CICIDS2017
applied to UNSW-NB15's 49 features and 10 classes (Normal + 9 attack
categories: Fuzzers, Analysis, Backdoors, DoS, Exploits, Generic,
Reconnaissance, Shellcode, Worms).
"""
import argparse
import os

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

LABEL_COLUMN = "attack_cat"  # UNSW-NB15's multi-class category column


def load_raw(train_path: str, test_path: str) -> pd.DataFrame:
    train = pd.read_csv(train_path, low_memory=False)
    test = pd.read_csv(test_path, low_memory=False)
    full = pd.concat([train, test], ignore_index=True)
    full.columns = [c.strip() for c in full.columns]
    # UNSW-NB15 encodes normal traffic with a NaN/empty attack_cat; fill it.
    full[LABEL_COLUMN] = full[LABEL_COLUMN].fillna("Normal").str.strip()
    full[LABEL_COLUMN] = full[LABEL_COLUMN].replace("", "Normal")
    # The binary 'label' column is redundant with attack_cat; drop it along
    # with the non-feature id column if present.
    drop_cols = [c for c in ["id", "label"] if c in full.columns]
    return full.drop(columns=drop_cols)


def clean(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    df = df.drop_duplicates()
    print(f"  removed {1 - len(df) / before:.4%} of rows")
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-file", default="data/raw/unsw_nb15/UNSW_NB15_training-set.csv")
    parser.add_argument("--test-file", default="data/raw/unsw_nb15/UNSW_NB15_testing-set.csv")
    parser.add_argument("--out-dir", default="data/processed/unsw_nb15")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    full = load_raw(args.train_file, args.test_file)
    full = clean(full)

    categorical_cols = [c for c in ["proto", "service", "state"] if c in full.columns]
    for c in categorical_cols:
        full[c] = full[c].astype("category").cat.codes

    feature_cols = [c for c in full.columns if c != LABEL_COLUMN]

    train_df, temp_df = train_test_split(
        full, test_size=0.4, stratify=full[LABEL_COLUMN], random_state=args.seed
    )
    val_df, test_df = train_test_split(
        temp_df, test_size=0.5, stratify=temp_df[LABEL_COLUMN], random_state=args.seed
    )

    scaler = StandardScaler().fit(train_df[feature_cols])
    label_enc = LabelEncoder().fit(full[LABEL_COLUMN])

    def _apply(df):
        X = scaler.transform(df[feature_cols])
        y = label_enc.transform(df[LABEL_COLUMN])
        return X, y

    X_tr, y_tr = _apply(train_df)
    X_va, y_va = _apply(val_df)
    X_te, y_te = _apply(test_df)

    os.makedirs(args.out_dir, exist_ok=True)
    out_path = os.path.join(args.out_dir, f"stratified_seed{args.seed}.npz")
    np.savez_compressed(out_path, X_train=X_tr, y_train=y_tr,
                         X_val=X_va, y_val=y_va, X_test=X_te, y_test=y_te,
                         num_classes=len(label_enc.classes_), class_names=label_enc.classes_.astype(str))
    print(f"Saved -> {out_path}  (features={X_tr.shape[1]}, classes={len(label_enc.classes_)})")
    if X_tr.shape[1] != 49:
        print(f"WARNING: manuscript states 49 UNSW-NB15 features; the official train/test partition files "
              f"yield {X_tr.shape[1]} after dropping id/label/attack_cat. See CONSISTENCY.md item 6.")


if __name__ == "__main__":
    main()
