# Dataset layout

## CICIDS2017 (`data/raw/cicids2017/`)

Expected files (CICFlowMeter daily CSVs, as distributed by UNB):
```
Monday-WorkingHours.pcap_ISCX.csv
Tuesday-WorkingHours.pcap_ISCX.csv
Wednesday-workingHours.pcap_ISCX.csv
Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv
Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv
Friday-WorkingHours-Morning.pcap_ISCX.csv
Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv
Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv
```
- Raw records: 2,830,743 (per manuscript Section IV-A)
- 78 features extracted via CICFlowMeter
- 15 classes (Benign + 14 attack categories)
- Used by both the stratified-split (`run_main_experiment.sh`) and the
  day-wise chronological-split (`run_chronological_split.sh`) pipelines —
  the latter requires the per-day file boundaries to remain intact, so do
  not concatenate/shuffle the files before preprocessing.

## NSL-KDD (`data/raw/nsl_kdd/`)

Expected files:
```
KDDTrain+.txt
KDDTest+.txt
```
- 148,517 training + 22,544 test records (per manuscript)
- 41 features, 5 classes (Normal + DoS, Probe, R2L, U2R)

## UNSW-NB15 (`data/raw/unsw_nb15/`)

Expected files:
```
UNSW_NB15_training-set.csv
UNSW_NB15_testing-set.csv
```
- 257,673 records (per manuscript)
- 49 features, 10 classes (Normal + 9 attack categories)

## Checksums

Populate this section with SHA-256 checksums of the files actually used,
once downloaded, so reviewers can verify they are working from the same
data version:

```
sha256sum data/raw/cicids2017/*.csv data/raw/nsl_kdd/*.txt data/raw/unsw_nb15/*.csv > data/raw/CHECKSUMS.sha256
```

## License / redistribution note

These datasets are governed by their original hosts' data-use terms
(UNB, UNSW Canberra). They are not redistributed in this repository;
users must obtain them directly from the sources listed in the main
README.
