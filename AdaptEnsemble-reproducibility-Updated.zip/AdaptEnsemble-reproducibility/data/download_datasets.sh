#!/usr/bin/env bash
# Downloads the three public benchmark datasets used in the manuscript.
# None of these datasets are redistributed in this repository; this script
# only automates fetching them from their original, official sources.
set -euo pipefail

RAW_DIR="$(dirname "$0")/raw"
mkdir -p "${RAW_DIR}/cicids2017" "${RAW_DIR}/nsl_kdd" "${RAW_DIR}/unsw_nb15"

echo "=================================================================="
echo "CICIDS2017"
echo "Source: https://www.unb.ca/cic/datasets/ids-2017.html"
echo "This dataset requires manual registration/download from UNB's site"
echo "(no direct-download API is provided by the host)."
echo "Place the 8 daily CSV files (CICFlowMeter output) under:"
echo "  ${RAW_DIR}/cicids2017/"
echo "=================================================================="

echo "=================================================================="
echo "NSL-KDD"
echo "Source: https://www.unb.ca/cic/datasets/nsl.html"
echo "Download KDDTrain+.txt and KDDTest+.txt and place under:"
echo "  ${RAW_DIR}/nsl_kdd/"
echo "=================================================================="

echo "=================================================================="
echo "UNSW-NB15"
echo "Source: https://research.unsw.edu.au/projects/unsw-nb15-dataset"
echo "Download the UNSW_NB15_training-set.csv and UNSW_NB15_testing-set.csv"
echo "files and place under:"
echo "  ${RAW_DIR}/unsw_nb15/"
echo "=================================================================="

echo ""
echo "All three sources require accepting the host institution's data-use"
echo "terms before download; this cannot be automated. See README_data.md"
echo "for expected file names and checksums once files are in place."
