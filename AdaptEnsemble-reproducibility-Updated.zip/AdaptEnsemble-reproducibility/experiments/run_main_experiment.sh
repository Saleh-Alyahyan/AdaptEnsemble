#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SEEDS=$(python -c "import yaml;print(*yaml.safe_load(open(\"config/seeds.yaml\"))[\"seeds\"])")
DEV=${DEVICE:-$(python -c "import torch;print(\"cuda\" if torch.cuda.is_available() else \"cpu\")")}
# Tables 2-3, Fig. 3-4 (CICIDS2017, stratified 60/20/20), Table 5 (convergence), Table 6 / Fig. 7 (weights)
for s in $SEEDS; do
  python -m src.train_adaptensemble --dataset cicids2017 --seed $s --tag main --device $DEV
  python -m src.baselines.static_ensembles --dataset cicids2017 --seed $s          # Table 2 static/DES-KNN rows
  python -m src.ablations.run_ablation --name dqn --dataset cicids2017 --seed $s --device $DEV   # DQN-Ensemble row + DQN convergence log
  python -m src.ablations.run_ablation --name lr_meta --dataset cicids2017 --seed $s --device $DEV
done
python -m src.evaluation.aggregate
python -m src.evaluation.convergence
python -m src.evaluation.weight_table
