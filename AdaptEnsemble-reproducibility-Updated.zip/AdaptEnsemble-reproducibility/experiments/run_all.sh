#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SEEDS=$(python -c "import yaml;print(*yaml.safe_load(open(\"config/seeds.yaml\"))[\"seeds\"])")
DEV=${DEVICE:-$(python -c "import torch;print(\"cuda\" if torch.cuda.is_available() else \"cpu\")")}
bash preprocessing/run_preprocessing.sh
for f in hparam_search main_experiment ablations baselines sensitivity_analysis cross_dataset chronological_split overhead_analysis; do
  bash experiments/run_$f.sh
done
