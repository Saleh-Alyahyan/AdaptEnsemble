#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SEEDS=$(python -c "import yaml;print(*yaml.safe_load(open(\"config/seeds.yaml\"))[\"seeds\"])")
DEV=${DEVICE:-$(python -c "import torch;print(\"cuda\" if torch.cuda.is_available() else \"cpu\")")}
# Table 10 + paired t-tests (Section IV-I)
for s in $SEEDS; do
  for b in stacking_dnn adaecelm cat_attn des_oracle moe_gate marl_alloc; do
    python -m src.baselines.run_baseline --name $b --dataset cicids2017 --seed $s --device $DEV
  done
done
python -m src.evaluation.aggregate
python -m src.evaluation.run_ttests
