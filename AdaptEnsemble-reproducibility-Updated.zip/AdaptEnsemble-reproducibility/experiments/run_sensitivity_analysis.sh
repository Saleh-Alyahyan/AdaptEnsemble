#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SEEDS=$(python -c "import yaml;print(*yaml.safe_load(open(\"config/seeds.yaml\"))[\"seeds\"])")
DEV=${DEVICE:-$(python -c "import torch;print(\"cuda\" if torch.cuda.is_available() else \"cpu\")")}
# Tables 7-8, Fig. 8 (a: epsilon, b: alpha, c: K)
for s in $SEEDS; do
  for eps in 0.05 0.10 0.30 0.40; do python -m src.train_adaptensemble --seed $s --epsilon $eps --tag eps$eps --device $DEV; done
  for al in 0.1 0.2 0.4 0.5;      do python -m src.train_adaptensemble --seed $s --alpha $al   --tag alpha$al --device $DEV; done
  for k in 2 3 4;                 do python -m src.train_adaptensemble --seed $s --k $k       --tag K$k --device $DEV; done
done
python -m src.evaluation.aggregate     # eps=0.20, alpha=0.30, K=5 are the main runs
