#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SEEDS=$(python -c "import yaml;print(*yaml.safe_load(open(\"config/seeds.yaml\"))[\"seeds\"])")
DEV=${DEVICE:-$(python -c "import torch;print(\"cuda\" if torch.cuda.is_available() else \"cpu\")")}
# Table 11: zero-configuration transfer; Stacking (LR) and DQN-Ensemble comparison rows
for ds in nsl_kdd unsw_nb15; do
  for s in $SEEDS; do
    python -m src.train_adaptensemble --dataset $ds --seed $s --tag cross --device $DEV
    python -m src.baselines.static_ensembles --dataset $ds --seed $s
    python -m src.ablations.run_ablation --name dqn --dataset $ds --seed $s --device $DEV
  done
done
python -m src.evaluation.aggregate
