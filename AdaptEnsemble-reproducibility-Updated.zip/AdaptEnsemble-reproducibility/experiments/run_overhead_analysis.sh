#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SEEDS=$(python -c "import yaml;print(*yaml.safe_load(open(\"config/seeds.yaml\"))[\"seeds\"])")
DEV=${DEVICE:-$(python -c "import torch;print(\"cuda\" if torch.cuda.is_available() else \"cpu\")")}
# Table 9 (GPU, batch 1024) and CPU latency at batch 1 / 32 / 256 (Section IV-H)
if [ "$DEV" = "cuda" ]; then python -m src.evaluation.compute_overhead --device cuda --batch-size 1024; fi
for bs in 1 32 256; do python -m src.evaluation.compute_overhead --device cpu --batch-size $bs; done
