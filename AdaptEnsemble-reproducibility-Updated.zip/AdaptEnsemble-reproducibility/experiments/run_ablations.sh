#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SEEDS=$(python -c "import yaml;print(*yaml.safe_load(open(\"config/seeds.yaml\"))[\"seeds\"])")
DEV=${DEVICE:-$(python -c "import torch;print(\"cuda\" if torch.cuda.is_available() else \"cpu\")")}
# Table 4 (+ nested D_pol/D_sel check of Section IV-A)
for s in $SEEDS; do
  for abl in no_disagree no_entropy no_calibration random_weights; do
    python -m src.train_adaptensemble --dataset cicids2017 --seed $s --ablation $abl --tag ablation --device $DEV
  done
  for name in lr_meta mlp_gating moe_gate_ce linucb dqn tabnet; do
    python -m src.ablations.run_ablation --name $name --dataset cicids2017 --seed $s --device $DEV
  done
  python -m src.train_adaptensemble --dataset cicids2017 --seed $s --nested-split --tag nested --device $DEV
done
python -m src.evaluation.aggregate
