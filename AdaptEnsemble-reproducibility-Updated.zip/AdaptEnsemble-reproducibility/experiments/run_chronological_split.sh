#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SEEDS=$(python -c "import yaml;print(*yaml.safe_load(open(\"config/seeds.yaml\"))[\"seeds\"])")
DEV=${DEVICE:-$(python -c "import torch;print(\"cuda\" if torch.cuda.is_available() else \"cpu\")")}
# Section IV-K: Mon+Tue train, Wed val, Thu+Fri test. NOTE: several test attack classes are absent from D_train
# (preprocess_cicids2017.py prints which); verify the result against the manuscript's 99.61% (see CONSISTENCY.md).
for s in $SEEDS; do
  python -m src.train_adaptensemble --dataset cicids2017 --split chronological --seed $s --tag chrono --device $DEV
done
python -m src.evaluation.aggregate
