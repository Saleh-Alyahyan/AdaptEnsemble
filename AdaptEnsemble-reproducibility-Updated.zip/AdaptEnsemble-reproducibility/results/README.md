# results/
Populated by running `experiments/run_all.sh`. Nothing here is pre-filled: numbers must come from actual runs.
- `raw_per_seed/` one JSON per (experiment, seed): weighted metrics, macro-F1, balanced accuracy, per-class P/R/F1,
  per-class TP/FN/FP and Clopper-Pearson recall CIs.
- `aggregated/` `summary_mean_std.csv`, `confidence_intervals.csv`, `paired_ttests.txt`.
- `logs/` per-episode PPO training reward (convergence curves).
